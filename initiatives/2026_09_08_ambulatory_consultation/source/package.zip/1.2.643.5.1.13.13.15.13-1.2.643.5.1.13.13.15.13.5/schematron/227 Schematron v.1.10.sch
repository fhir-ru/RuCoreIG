<schema xmlns="http://purl.oclc.org/dsdl/schematron" queryBinding="xslt2">
	<ns prefix="xsi" uri="http://www.w3.org/2001/XMLSchema-instance"/>
	<ns prefix="identity" uri="urn:hl7-ru:identity"/>
	<ns prefix="address" uri="urn:hl7-ru:address"/>
	<ns prefix="medService" uri="urn:hl7-ru:medService"/>
	<ns prefix="fias" uri="urn:hl7-ru:fias"/>
	<pattern>
		<rule context="ClinicalDocument">
			<assert test="count(@nullFlavor)=0">Элемент ClinicalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(realmCode)=1">У1-1: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент realmCode</assert>
			<assert test="count(typeId)=1">У1-2: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент typeId</assert>
			<assert test="count(templateId)=1">У1-3: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент templateId</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)='.51'])=1">У1-4: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51)</assert>
			<assert test="count(code)=1">У1-5: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У1-6: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(effectiveTime)=1">У1-7: Элемент ClinicalDocument ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(confidentialityCode)=1">У1-8: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент confidentialityCode</assert>
			<assert test="count(languageCode)=1">У1-9: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент languageCode</assert>
			<assert test="count(setId)=1">У1-10: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент setId (Элемент setId обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.50)</assert>
			<assert test="count(versionNumber)=1">У1-11: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент versionNumber</assert>
			<assert test="count(recordTarget)=1">У1-12: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент recordTarget</assert>
			<assert test="count(author)=1">У1-13: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент author</assert>
			<assert test="count(custodian)=1">У1-14: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент custodian</assert>
			<assert test="count(informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13'])=1">У1-15: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент informationRecipient</assert>
			<assert test="count(informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')])>=0">У1-16: Элемент ClinicalDocument МОЖЕТ содержать произвольное количество [0..*] элементов informationRecipient</assert>
			<assert test="count(legalAuthenticator)=1">У1-17: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент legalAuthenticator</assert>
			<assert test="count(participant[@typeCode='IND'])=[0,1]">У1-18: Элемент ClinicalDocument МОЖЕТ содержать не более одного [0..1] элемента participant</assert>
			<assert test="count(participant[@typeCode='REF'])=[0,1]">У1-19: Элемент ClinicalDocument МОЖЕТ содержать не более одного [0..1] элемента participant</assert>
			<assert test="count(inFulfillmentOf)=[0,1]">У1-20: Элемент ClinicalDocument МОЖЕТ содержать не более одного [0..1] элемента inFulfillmentOf</assert>
			<assert test="count(documentationOf)=1">У1-21: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент documentationOf</assert>
			<assert test="count(componentOf)=[0,1]">У1-22: Элемент ClinicalDocument МОЖЕТ содержать не более одного [0..1] элемента componentOf</assert>
			<assert test="count(component)=1">У1-23: Элемент ClinicalDocument ОБЯЗАН содержать один [1..1] элемент component</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/realmCode">
			<assert test="count(@nullFlavor)=0">У1-1: Элемент ClinicalDocument/realmCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='RU'">У1-1: Элемент realmCode обязан содержать один атрибут @code со значением "RU"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/typeId">
			<assert test="count(@nullFlavor)=0">У1-2: Элемент ClinicalDocument/typeId не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='2.16.840.1.113883.1.3'">У1-2: Элемент typeId обязан содержать один атрибут @root со значением "2.16.840.1.113883.1.3"</assert>
			<assert test="@extension='POCD_MT000040'">У1-2: Элемент typeId обязан содержать один атрибут @extension со значением "POCD_MT000040"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/templateId">
			<assert test="count(@nullFlavor)=0">У1-3: Элемент ClinicalDocument/templateId не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='1.2.643.5.1.13.13.15.13.5'">У1-3: Элемент templateId обязан содержать один атрибут @root со значением "1.2.643.5.1.13.13.15.13.5"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/id[substring(@root, string-length(@root) - 2)='.51']">
			<assert test="count(@nullFlavor)=0">У1-4: Элемент ClinicalDocument/id[substring(@root, string-length(@root) - 2)='.51'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-4: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У1-4: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У1-4: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/code">
			<assert test="count(@nullFlavor)=0">У1-5: Элемент ClinicalDocument/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code=['227','5']">У1-5: Элемент code обязан содержать один атрибут @code со значением "227" или "5"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1520','1.2.643.5.1.13.13.99.2.41','1.2.643.5.1.13.13.11.1522','1.2.643.5.1.13.2.1.1.646', '1.2.643.5.1.13.13.11.1115', '1.2.643.5.1.13.13.99.2.195']">У1-5: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1520" или "1.2.643.5.1.13.13.11.1522"</assert>
			<assert test="@codeSystemName!=''">У1-5: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У1-5: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-5: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="count(translation)=1">У1-5.1: Элемент code ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У1-5 -->
	<pattern>
		<rule context="ClinicalDocument/code[@codeSystem=['1.2.643.5.1.13.13.11.1520','1.2.643.5.1.13.13.99.2.41']]">
			<assert test="@code='227'">У1-5: Элемент code обязан содержать атрибут @code со значением "227"</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У1-5 -->
	<pattern>
		<rule context="ClinicalDocument/code[@codeSystem=['1.2.643.5.1.13.13.11.1522','1.2.643.5.1.13.2.1.1.646', '1.2.643.5.1.13.13.11.1115', '1.2.643.5.1.13.13.99.2.195']]">
			<assert test="@code='5'">У1-5: Элемент code обязан содержать атрибут @code со значением "5"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/code/translation">
			<assert test="count(@nullFlavor)=0">У1-5.1: Элемент ClinicalDocument/code/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='13'">У1-5.1: Элемент translation обязан содержать один атрибут @code со значением "13"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.1079'">У1-5.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.1079"</assert>
			<assert test="@codeSystemName!=''">У1-5.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У1-5.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-5.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/title">
			<assert test="count(@nullFlavor)=0">У1-6: Элемент ClinicalDocument/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-6: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/effectiveTime[not(@nullFlavor)]">
			<assert test="@value!=''">У1-7: Элемент effectiveTime должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/effectiveTime[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/confidentialityCode">
			<assert test="count(@nullFlavor)=0">У1-8: Элемент ClinicalDocument/confidentialityCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.285','1.2.643.5.1.13.2.1.1.1504.9','2.16.840.1.113883.2.35.10.9','1.2.643.5.1.13.13.11.1116']">У1-8: Элемент confidentialityCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.285"</assert>
			<assert test="@codeSystemName!=''">У1-8: Элемент confidentialityCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-8: Элемент confidentialityCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-8: Элемент confidentialityCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-8: Элемент confidentialityCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/languageCode">
			<assert test="count(@nullFlavor)=0">У1-9: Элемент ClinicalDocument/languageCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='ru-RU'">У1-9: Элемент languageCode обязан содержать один атрибут @code со значением "ru-RU"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/setId">
			<assert test="count(@nullFlavor)=0">У1-10: Элемент ClinicalDocument/setId не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-10: Элемент setId обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.50</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.50$')">У1-10: Элемент setId обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.50</assert>
			<assert test="@extension!=''">У1-10: Элемент setId обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/versionNumber">
			<assert test="count(@nullFlavor)=0">У1-11: Элемент ClinicalDocument/versionNumber не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-11: Элемент versionNumber обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget">
			<assert test="count(@nullFlavor)=0">У1-12: Элемент ClinicalDocument/recordTarget не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(patientRole)=1">У1-12.1: Элемент recordTarget ОБЯЗАН содержать один [1..1] элемент patientRole</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole">
			<assert test="count(@nullFlavor)=0">У1-12.1: Элемент ClinicalDocument/recordTarget/patientRole не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)='.10'])=1">У1-12.1.1: Элемент patientRole ОБЯЗАН содержать один [1..1] элемент id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.10)</assert>
			<assert test="count(id[2])=1">У1-12.1.2: Элемент patientRole ДОЛЖЕН содержать один [1..1] элемент id (СНИЛС пациента)</assert>
			<assert test="count(identity:IdentityDoc)=1">У1-12.1.3: Элемент patientRole ДОЛЖЕН содержать один [1..1] элемент identity:IdentityDoc</assert>
			<assert test="count(identity:InsurancePolicy)=1">У1-12.1.4: Элемент patientRole ДОЛЖЕН содержать один [1..1] элемент identity:InsurancePolicy</assert>
			<assert test="count(addr)=[1,2]">У1-12.1.5: Элемент patientRole ДОЛЖЕН содержать от одного до двух [1..2] элементов addr</assert>
			<assert test="count(telecom)>=0">У1-12.1.6: Элемент patientRole МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(patient)=1">У1-12.1.7: Элемент patientRole ОБЯЗАН содержать один [1..1] элемент patient</assert>
			<assert test="count(providerOrganization)=1">У1-12.1.8: Элемент patientRole ОБЯЗАН содержать один [1..1] элемент providerOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/id[substring(@root, string-length(@root) - 2)='.10']">
			<assert test="count(@nullFlavor)=0">У1-12.1.1: Элемент ClinicalDocument/recordTarget/patientRole/id[substring(@root, string-length(@root) - 2)='.10'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-12.1.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.10</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.10$')">У1-12.1.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.10</assert>
			<assert test="@extension!=''">У1-12.1.1: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.100.3'">У1-12.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.100.3"</assert>
			<assert test="@extension!=''">У1-12.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc[not(@nullFlavor)]">
			<assert test="count(identity:IdentityCardType)=1">У1-12.1.3.1: Элемент identity:IdentityDoc ОБЯЗАН содержать один [1..1] элемент identity:IdentityCardType</assert>
			<assert test="count(identity:Series)=1">У1-12.1.3.2: Элемент identity:IdentityDoc ДОЛЖЕН содержать один [1..1] элемент identity:Series</assert>
			<assert test="count(identity:Number)=1">У1-12.1.3.3: Элемент identity:IdentityDoc ОБЯЗАН содержать один [1..1] элемент identity:Number</assert>
			<assert test="count(identity:IssueOrgName)=1">У1-12.1.3.4: Элемент identity:IdentityDoc ДОЛЖЕН содержать один [1..1] элемент identity:IssueOrgName</assert>
			<assert test="count(identity:IssueOrgCode)=1">У1-12.1.3.5: Элемент identity:IdentityDoc ДОЛЖЕН содержать один [1..1] элемент identity:IssueOrgCode</assert>
			<assert test="count(identity:IssueDate)=1">У1-12.1.3.6: Элемент identity:IdentityDoc ОБЯЗАН содержать один [1..1] элемент identity:IssueDate</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:IdentityCardType">
			<assert test="count(@nullFlavor)=0">У1-12.1.3.1: Элемент ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:IdentityCardType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.48','1.2.643.5.1.13.13.11.1011','1.2.643.5.1.13.2.1.1.736']">У1-12.1.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.48"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:Series[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.3.2: Элемент identity:Series должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:Number">
			<assert test="count(@nullFlavor)=0">У1-12.1.3.3: Элемент ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:Number не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.3.3: Элемент identity:Number должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:IssueOrgName[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.3.4: Элемент identity:IssueOrgName должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:IssueOrgCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.3.5: Элемент identity:IssueOrgCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:IssueDate">
			<assert test="count(@nullFlavor)=0">У1-12.1.3.6: Элемент ClinicalDocument/recordTarget/patientRole/identity:IdentityDoc/identity:IssueDate не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-12.1.3.6: Элемент identity:IssueDate обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy[not(@nullFlavor)]">
			<assert test="count(identity:InsurancePolicyType)=1">У1-12.1.4.1: Элемент identity:InsurancePolicy ОБЯЗАН содержать один [1..1] элемент identity:InsurancePolicyType</assert>
			<assert test="count(identity:Series)=[0,1]">У1-12.1.4.2: Элемент identity:InsurancePolicy МОЖЕТ содержать не более одного [0..1] элемента identity:Series</assert>
			<assert test="count(identity:Number)=1">У1-12.1.4.3: Элемент identity:InsurancePolicy ОБЯЗАН содержать один [1..1] элемент identity:Number</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy/identity:InsurancePolicyType">
			<assert test="count(@nullFlavor)=0">У1-12.1.4.1: Элемент ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy/identity:InsurancePolicyType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1035'">У1-12.1.4.1: Элемент identity:InsurancePolicyType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1035"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.4.1: Элемент identity:InsurancePolicyType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.4.1: Элемент identity:InsurancePolicyType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.4.1: Элемент identity:InsurancePolicyType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.4.1: Элемент identity:InsurancePolicyType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy/identity:Series">
			<assert test="count(@nullFlavor)=0">У1-12.1.4.2: Элемент ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy/identity:Series не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.4.2: Элемент identity:Series должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy/identity:Number">
			<assert test="count(@nullFlavor)=0">У1-12.1.4.3: Элемент ClinicalDocument/recordTarget/patientRole/identity:InsurancePolicy/identity:Number не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.4.3: Элемент identity:Number должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr[not(@nullFlavor)]">
			<assert test="count(@use!='')=[0,1]">У1-12.1.5: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.5: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(address:Type)=1">У1-12.1.5.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:Type</assert>
			<assert test="count(streetAddressLine)=1">У1-12.1.5.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-12.1.5.3: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-12.1.5.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-12.1.5.5: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/address:Type">
			<assert test="count(@nullFlavor)=0">У1-12.1.5.1: Элемент ClinicalDocument/recordTarget/patientRole/addr/address:Type не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1504','1.2.643.5.1.13.13.11.1415','1.2.643.5.1.13.13.99.2.241']">У1-12.1.5.1: Элемент address:Type обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1504"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.5.1: Элемент address:Type обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.5.1: Элемент address:Type обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.5.1: Элемент address:Type обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.5.1: Элемент address:Type обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-12.1.5.2: Элемент ClinicalDocument/recordTarget/patientRole/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.5.2: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-12.1.5.3: Элемент ClinicalDocument/recordTarget/patientRole/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-12.1.5.3: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.5.3: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.5.3: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.5.3: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.5.3: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.5.4: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-12.1.5.5.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-12.1.5.5.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-12.1.5.5.1: Элемент ClinicalDocument/recordTarget/patientRole/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.5.5.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.5.5.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/telecom">
			<assert test="count(@nullFlavor)=0">У1-12.1.6: Элемент ClinicalDocument/recordTarget/patientRole/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-12.1.6: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.6: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-12.1.6: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient">
			<assert test="count(@nullFlavor)=0">У1-12.1.7: Элемент ClinicalDocument/recordTarget/patientRole/patient не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У1-12.1.7.1: Элемент patient ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(administrativeGenderCode)=1">У1-12.1.7.2: Элемент patient ДОЛЖЕН содержать один [1..1] элемент administrativeGenderCode</assert>
			<assert test="count(birthTime)=1">У1-12.1.7.3: Элемент patient ДОЛЖЕН содержать один [1..1] элемент birthTime</assert>
			<assert test="count(guardian)=[0,1]">У1-12.1.7.4: Элемент patient МОЖЕТ содержать не более одного [0..1] элемента guardian</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/name">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У1-12.1.7.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У1-12.1.7.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У1-12.1.7.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/name/family">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.1.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/name/given">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.1.2: Элемент ClinicalDocument/recordTarget/patientRole/patient/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.1.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/administrativeGenderCode[not(@nullFlavor)]">
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1040','1.2.643.5.1.13.2.1.1.156']">У1-12.1.7.2: Элемент administrativeGenderCode должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1040"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.7.2: Элемент administrativeGenderCode должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.7.2: Элемент administrativeGenderCode должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.7.2: Элемент administrativeGenderCode должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.7.2: Элемент administrativeGenderCode должен содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/administrativeGenderCode[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/birthTime[not(@nullFlavor)]">
			<assert test="@value!=''">У1-12.1.7.3: Элемент birthTime должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/birthTime[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='GUARD'">У1-12.1.7.4: Элемент guardian обязан содержать один атрибут @classCode со значением "GUARD"</assert>
			<assert test="count(id[@root='1.2.643.100.3'])=[0,1]">У1-12.1.7.4.1: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента id</assert>
			<assert test="count(identity:IdentityDoc)=[0,1]">У1-12.1.7.4.2: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента identity:IdentityDoc</assert>
			<assert test="count(identity:AuthorityDoc)=[0,1]">У1-12.1.7.4.3: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента identity:AuthorityDoc</assert>
			<assert test="count(code)=[0,1]">У1-12.1.7.4.4: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента code</assert>
			<assert test="count(addr)=[0,1]">У1-12.1.7.4.5: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
			<assert test="count(telecom)>=0">У1-12.1.7.4.6: Элемент guardian МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(guardianPerson)=[0,1]">У1-12.1.7.4.7: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента guardianPerson</assert>
			<assert test="count(guardianOrganization)=[0,1]">У1-12.1.7.4.8: Элемент guardian МОЖЕТ содержать не более одного [0..1] элемента guardianOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/id[@root='1.2.643.100.3']">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/id[@root='1.2.643.100.3'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='1.2.643.100.3'">У1-12.1.7.4.1: Элемент id обязан содержать один атрибут @root со значением "1.2.643.100.3"</assert>
			<assert test="@extension!=''">У1-12.1.7.4.1: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.2: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(identity:IdentityCardType)=1">У1-12.1.7.4.2.1: Элемент identity:IdentityDoc ОБЯЗАН содержать один [1..1] элемент identity:IdentityCardType</assert>
			<assert test="count(identity:Series)=1">У1-12.1.7.4.2.2: Элемент identity:IdentityDoc ДОЛЖЕН содержать один [1..1] элемент identity:Series</assert>
			<assert test="count(identity:Number)=1">У1-12.1.7.4.2.3: Элемент identity:IdentityDoc ОБЯЗАН содержать один [1..1] элемент identity:Number</assert>
			<assert test="count(identity:IssueOrgName)=1">У1-12.1.7.4.2.4: Элемент identity:IdentityDoc ДОЛЖЕН содержать один [1..1] элемент identity:IssueOrgName</assert>
			<assert test="count(identity:IssueOrgCode)=1">У1-12.1.7.4.2.5: Элемент identity:IdentityDoc ДОЛЖЕН содержать один [1..1] элемент identity:IssueOrgCode</assert>
			<assert test="count(identity:IssueDate)=1">У1-12.1.7.4.2.6: Элемент identity:IdentityDoc ОБЯЗАН содержать один [1..1] элемент identity:IssueDate</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:IdentityCardType">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.2.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:IdentityCardType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.48','1.2.643.5.1.13.13.11.1011','1.2.643.5.1.13.2.1.1.736']">У1-12.1.7.4.2.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.48"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.7.4.2.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.7.4.2.1: Элемент identity:IdentityCardType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.7.4.2.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.7.4.2.1: Элемент identity:IdentityCardType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:Series[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.2.2: Элемент identity:Series должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:Number">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.2.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:Number не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.2.3: Элемент identity:Number должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:IssueOrgName[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.2.4: Элемент identity:IssueOrgName должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:IssueOrgCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.2.5: Элемент identity:IssueOrgCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:IssueDate">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.2.6: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:IdentityDoc/identity:IssueDate не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-12.1.7.4.2.6: Элемент identity:IssueDate обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(identity:IdentityCardType)=1">У1-12.1.7.4.3.1: Элемент identity:AuthorityDoc ОБЯЗАН содержать один [1..1] элемент identity:IdentityCardType</assert>
			<assert test="count(identity:Series)=1">У1-12.1.7.4.3.2: Элемент identity:AuthorityDoc ДОЛЖЕН содержать один [1..1] элемент identity:Series</assert>
			<assert test="count(identity:Number)=1">У1-12.1.7.4.3.3: Элемент identity:AuthorityDoc ОБЯЗАН содержать один [1..1] элемент identity:Number</assert>
			<assert test="count(identity:IssueOrgName)=1">У1-12.1.7.4.3.4: Элемент identity:AuthorityDoc ДОЛЖЕН содержать один [1..1] элемент identity:IssueOrgName</assert>
			<assert test="count(identity:IssueDate)=1">У1-12.1.7.4.3.5: Элемент identity:AuthorityDoc ОБЯЗАН содержать один [1..1] элемент identity:IssueDate</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:IdentityCardType">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.3.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:IdentityCardType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.313'">У1-12.1.7.4.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.313"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.7.4.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.7.4.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.7.4.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.7.4.3.1: Элемент identity:IdentityCardType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:Series[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.3.2: Элемент identity:Series должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:Number">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.3.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:Number не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.3.3: Элемент identity:Number должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:IssueOrgName[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.3.4: Элемент identity:IssueOrgName должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:IssueDate">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.3.5: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/identity:AuthorityDoc/identity:IssueDate не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-12.1.7.4.3.5: Элемент identity:IssueDate обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/code">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.4: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.14','1.2.643.5.1.13.2.1.1.1504.40']">У1-12.1.7.4.4: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.14"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.7.4.4: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.7.4.4: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.7.4.4: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.7.4.4: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.5: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-12.1.7.4.5: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.7.4.5: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-12.1.7.4.5.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-12.1.7.4.5.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-12.1.7.4.5.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-12.1.7.4.5.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.5.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.5.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.5.2: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-12.1.7.4.5.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.7.4.5.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.7.4.5.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.7.4.5.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.7.4.5.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.5.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-12.1.7.4.5.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-12.1.7.4.5.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.5.4.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.5.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.5.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/telecom">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.6: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-12.1.7.4.6: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.7.4.6: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-12.1.7.4.6: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.7: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У1-12.1.7.4.7.1: Элемент guardianPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.7.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У1-12.1.7.4.7.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У1-12.1.7.4.7.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У1-12.1.7.4.7.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name/family">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.7.1.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.7.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name/given">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.7.1.2: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.7.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.7.1.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.7.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=[0,1]">У1-12.1.7.4.8.1: Элемент guardianOrganization МОЖЕТ содержать не более одного [0..1] элемента id</assert>
			<assert test="count(identity:Props)=1">У1-12.1.7.4.8.2: Элемент guardianOrganization ДОЛЖЕН содержать один [1..1] элемент identity:Props</assert>
			<assert test="count(name)=1">У1-12.1.7.4.8.3: Элемент guardianOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(addr)=[0,1]">У1-12.1.7.4.8.4: Элемент guardianOrganization МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-12.1.7.4.8.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-12.1.7.4.8.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-12.1.7.4.8.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props[not(@nullFlavor)]">
			<assert test="count(identity:Ogrn)=[0,1]">У1-12.1.7.4.8.2.1: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Ogrn</assert>
			<assert test="count(identity:Ogrnip)=[0,1]">У1-12.1.7.4.8.2.2: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Ogrnip</assert>
			<assert test="count(identity:Okpo)=[0,1]">У1-12.1.7.4.8.2.3: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Okpo</assert>
			<assert test="count(identity:Okato)=[0,1]">У1-12.1.7.4.8.2.4: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Okato</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Ogrn">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.2.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Ogrn не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.2.1: Элемент identity:Ogrn должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Ogrnip">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.2.2: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Ogrnip не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.2.2: Элемент identity:Ogrnip должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Okpo">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.2.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Okpo не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.2.3: Элемент identity:Okpo должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Okato">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.2.4: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/identity:Props/identity:Okato не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.2.4: Элемент identity:Okato должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.3: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.3: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.4: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-12.1.7.4.8.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.7.4.8.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-12.1.7.4.8.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-12.1.7.4.8.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-12.1.7.4.8.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-12.1.7.4.8.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.4.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.4.2: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-12.1.7.4.8.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.7.4.8.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.7.4.8.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.7.4.8.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.7.4.8.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.8.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-12.1.7.4.8.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-12.1.7.4.8.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-12.1.7.4.8.4.4.1: Элемент ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.7.4.8.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/patient/guardian/guardianOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.7.4.8.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization">
			<assert test="count(@nullFlavor)=0">У1-12.1.8: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=1">У1-12.1.8.1: Элемент providerOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(id[@root='1.2.643.5.1.13.2.1.1.1504.101'])=[0,1]">У1-12.1.8.2: Элемент providerOrganization МОЖЕТ содержать не более одного [0..1] элемента id</assert>
			<assert test="count(identity:Props)=1">У1-12.1.8.3: Элемент providerOrganization ДОЛЖЕН содержать один [1..1] элемент identity:Props</assert>
			<assert test="count(name)=1">У1-12.1.8.4: Элемент providerOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)>=0">У1-12.1.8.5: Элемент providerOrganization МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(addr)=[0,1]">У1-12.1.8.6: Элемент providerOrganization МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.1: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-12.1.8.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-12.1.8.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-12.1.8.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/id[@root='1.2.643.5.1.13.2.1.1.1504.101']">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.2: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/id[@root='1.2.643.5.1.13.2.1.1.1504.101'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='1.2.643.5.1.13.2.1.1.1504.101'">У1-12.1.8.2: Элемент id обязан содержать один атрибут @root со значением "1.2.643.5.1.13.2.1.1.1504.101"</assert>
			<assert test="@extension!=''">У1-12.1.8.2: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
			<assert test="@assigningAuthorityName!=''">У1-12.1.8.2: Элемент id обязан содержать один атрибут @assigningAuthorityName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props[not(@nullFlavor)]">
			<assert test="count(identity:Ogrn)=[0,1]">У1-12.1.8.3.1: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Ogrn</assert>
			<assert test="count(identity:Ogrnip)=[0,1]">У1-12.1.8.3.2: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Ogrnip</assert>
			<assert test="count(identity:Okpo)=[0,1]">У1-12.1.8.3.3: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Okpo</assert>
			<assert test="count(identity:Okato)=[0,1]">У1-12.1.8.3.4: Элемент identity:Props МОЖЕТ содержать не более одного [0..1] элемента identity:Okato</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Ogrn">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.3.1: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Ogrn не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.3.1: Элемент identity:Ogrn должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Ogrnip">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.3.2: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Ogrnip не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.3.2: Элемент identity:Ogrnip должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Okpo">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.3.3: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Okpo не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.3.3: Элемент identity:Okpo должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Okato">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.3.4: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/identity:Props/identity:Okato не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.3.4: Элемент identity:Okato должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.4: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.4: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/telecom">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.5: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-12.1.8.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.8.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-12.1.8.5: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.6: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-12.1.8.6: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-12.1.8.6: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-12.1.8.6.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-12.1.8.6.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-12.1.8.6.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-12.1.8.6.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.6.1: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.6.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.6.2: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-12.1.8.6.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-12.1.8.6.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-12.1.8.6.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-12.1.8.6.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-12.1.8.6.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.8.6.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-12.1.8.6.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-12.1.8.6.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-12.1.8.6.4.1: Элемент ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-12.1.8.6.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/recordTarget/patientRole/providerOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-12.1.8.6.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author">
			<assert test="count(@nullFlavor)=0">У1-13: Элемент ClinicalDocument/author не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(time)=1">У1-13.1: Элемент author ДОЛЖЕН содержать один [1..1] элемент time</assert>
			<assert test="count(assignedAuthor)=1">У1-13.2: Элемент author ОБЯЗАН содержать один [1..1] элемент assignedAuthor</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/time">
			<assert test="@nullFlavor='NI'">У1-13.1: Элемент time обязан содержать один атрибут @nullFlavor со значением "NI"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor">
			<assert test="count(@nullFlavor)=0">У1-13.2: Элемент ClinicalDocument/author/assignedAuthor не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)='.70'])=1">У1-13.2.1: Элемент assignedAuthor ОБЯЗАН содержать один [1..1] элемент id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70)</assert>
			<assert test="count(id[@root='1.2.643.100.3'])=1">У1-13.2.2: Элемент assignedAuthor ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(code)=1">У1-13.2.3: Элемент assignedAuthor ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(addr)=[0,1]">У1-13.2.4: Элемент assignedAuthor МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
			<assert test="count(telecom)>=0">У1-13.2.5: Элемент assignedAuthor МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(assignedPerson)=1">У1-13.2.6: Элемент assignedAuthor ОБЯЗАН содержать один [1..1] элемент assignedPerson</assert>
			<assert test="count(representedOrganization)=[0,1]">У1-13.2.7: Элемент assignedAuthor МОЖЕТ содержать не более одного [0..1] элемента representedOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/id[substring(@root, string-length(@root) - 2)='.70']">
			<assert test="count(@nullFlavor)=0">У1-13.2.1: Элемент ClinicalDocument/author/assignedAuthor/id[substring(@root, string-length(@root) - 2)='.70'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-13.2.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У1-13.2.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У1-13.2.1: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/id[@root='1.2.643.100.3']">
			<assert test="count(@nullFlavor)=0">У1-13.2.2: Элемент ClinicalDocument/author/assignedAuthor/id[@root='1.2.643.100.3'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='1.2.643.100.3'">У1-13.2.2: Элемент id обязан содержать один атрибут @root со значением "1.2.643.100.3"</assert>
			<assert test="@extension!=''">У1-13.2.2: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/code">
			<assert test="count(@nullFlavor)=0">У1-13.2.3: Элемент ClinicalDocument/author/assignedAuthor/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1002','1.2.643.5.1.13.2.1.1.733']">У1-13.2.3: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1002"</assert>
			<assert test="@codeSystemName!=''">У1-13.2.3: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-13.2.3: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-13.2.3: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-13.2.3: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr">
			<assert test="count(@nullFlavor)=0">У1-13.2.4: Элемент ClinicalDocument/author/assignedAuthor/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-13.2.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-13.2.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-13.2.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-13.2.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-13.2.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-13.2.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-13.2.4.1: Элемент ClinicalDocument/author/assignedAuthor/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-13.2.4.2: Элемент ClinicalDocument/author/assignedAuthor/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-13.2.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-13.2.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-13.2.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-13.2.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-13.2.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-13.2.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-13.2.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-13.2.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-13.2.4.4.1: Элемент ClinicalDocument/author/assignedAuthor/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-13.2.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/telecom">
			<assert test="count(@nullFlavor)=0">У1-13.2.5: Элемент ClinicalDocument/author/assignedAuthor/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-13.2.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-13.2.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-13.2.5: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/assignedPerson">
			<assert test="count(@nullFlavor)=0">У1-13.2.6: Элемент ClinicalDocument/author/assignedAuthor/assignedPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У1-13.2.6.1: Элемент assignedPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/assignedPerson/name">
			<assert test="count(@nullFlavor)=0">У1-13.2.6.1: Элемент ClinicalDocument/author/assignedAuthor/assignedPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У1-13.2.6.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У1-13.2.6.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У1-13.2.6.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/assignedPerson/name/family">
			<assert test="count(@nullFlavor)=0">У1-13.2.6.1.1: Элемент ClinicalDocument/author/assignedAuthor/assignedPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.6.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/assignedPerson/name/given">
			<assert test="count(@nullFlavor)=0">У1-13.2.6.1.2: Элемент ClinicalDocument/author/assignedAuthor/assignedPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.6.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/assignedPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У1-13.2.6.1.3: Элемент ClinicalDocument/author/assignedAuthor/assignedPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@xsi:type='ST')&lt;=1">У1-13.2.6.1.3: Элемент identity:Patronymic обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У1-13.2.6.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization">
			<assert test="count(@nullFlavor)=0">У1-13.2.7: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='ORG'">У1-13.2.7: Элемент representedOrganization обязан содержать один атрибут @classCode со значением "ORG"</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=1">У1-13.2.7.1: Элемент representedOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(name)=1">У1-13.2.7.2: Элемент representedOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)>=0">У1-13.2.7.3: Элемент representedOrganization МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(addr)=[0,1]">У1-13.2.7.4: Элемент representedOrganization МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.1: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-13.2.7.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-13.2.7.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-13.2.7.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.2: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.7.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/telecom">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.3: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-13.2.7.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-13.2.7.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-13.2.7.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.4: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-13.2.7.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-13.2.7.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-13.2.7.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-13.2.7.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-13.2.7.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-13.2.7.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.4.1: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.7.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.4.2: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-13.2.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-13.2.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-13.2.7.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-13.2.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-13.2.7.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-13.2.7.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-13.2.7.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-13.2.7.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-13.2.7.4.4.1: Элемент ClinicalDocument/author/assignedAuthor/representedOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-13.2.7.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/author/assignedAuthor/representedOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-13.2.7.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian">
			<assert test="count(@nullFlavor)=0">У1-14: Элемент ClinicalDocument/custodian не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(assignedCustodian)=1">У1-14.1: Элемент custodian ОБЯЗАН содержать один [1..1] элемент assignedCustodian</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian">
			<assert test="count(@nullFlavor)=0">У1-14.1: Элемент ClinicalDocument/custodian/assignedCustodian не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(representedCustodianOrganization)=1">У1-14.1.1: Элемент assignedCustodian ОБЯЗАН содержать один [1..1] элемент representedCustodianOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization">
			<assert test="count(@nullFlavor)=0">У1-14.1.1: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='ORG'">У1-14.1.1: Элемент representedCustodianOrganization обязан содержать один атрибут @classCode со значением "ORG"</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=1">У1-14.1.1.1: Элемент representedCustodianOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(name)=1">У1-14.1.1.2: Элемент representedCustodianOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)=[0,1]">У1-14.1.1.3: Элемент representedCustodianOrganization МОЖЕТ содержать не более одного [0..1] элемента telecom</assert>
			<assert test="count(addr)=1">У1-14.1.1.4: Элемент representedCustodianOrganization ОБЯЗАН содержать один [1..1] элемент addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.1: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-14.1.1.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-14.1.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-14.1.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.2: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-14.1.1.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/telecom">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.3: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-14.1.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-14.1.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-14.1.1.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.4: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-14.1.1.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-14.1.1.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-14.1.1.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-14.1.1.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-14.1.1.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-14.1.1.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.4.1: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-14.1.1.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.4.2: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-14.1.1.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-14.1.1.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-14.1.1.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-14.1.1.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-14.1.1.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-14.1.1.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-14.1.1.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-14.1.1.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-14.1.1.4.4.1: Элемент ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-14.1.1.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/custodian/assignedCustodian/representedCustodianOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-14.1.1.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']">
			<assert test="count(@nullFlavor)=0">У1-15: Элемент ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(intendedRecipient)=1">У1-15.1: Элемент informationRecipient ОБЯЗАН содержать один [1..1] элемент intendedRecipient</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient">
			<assert test="count(@nullFlavor)=0">У1-15.1: Элемент ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(receivedOrganization)=1">У1-15.1.1: Элемент intendedRecipient ОБЯЗАН содержать один [1..1] элемент receivedOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient/receivedOrganization">
			<assert test="count(@nullFlavor)=0">У1-15.1.1: Элемент ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient/receivedOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[@root='1.2.643.5.1.13'])=1">У1-15.1.1.1: Элемент receivedOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(name)=1">У1-15.1.1.2: Элемент receivedOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient/receivedOrganization/id[@root='1.2.643.5.1.13']">
			<assert test="count(@nullFlavor)=0">У1-15.1.1.1: Элемент ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient/receivedOrganization/id[@root='1.2.643.5.1.13'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='1.2.643.5.1.13'">У1-15.1.1.1: Элемент id обязан содержать один атрибут @root со значением "1.2.643.5.1.13"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient/receivedOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-15.1.1.2: Элемент ClinicalDocument/informationRecipient[intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13']/intendedRecipient/receivedOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-15.1.1.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]">
			<assert test="count(@nullFlavor)=0">У1-16: Элемент ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(intendedRecipient)=1">У1-16.1: Элемент informationRecipient ОБЯЗАН содержать один [1..1] элемент intendedRecipient</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient">
			<assert test="count(@nullFlavor)=0">У1-16.1: Элемент ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(receivedOrganization)=1">У1-16.1.1: Элемент intendedRecipient ОБЯЗАН содержать один [1..1] элемент receivedOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient/receivedOrganization">
			<assert test="count(@nullFlavor)=0">У1-16.1.1: Элемент ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient/receivedOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[1])=1">У1-16.1.1.1: Элемент receivedOrganization ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор получающей организации и (при наличии) уникальный идентификатор структурного подразделения)</assert>
			<assert test="count(name)=1">У1-16.1.1.2: Элемент receivedOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient/receivedOrganization/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У1-16.1.1.1: Элемент id должен содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-16.1.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-16.1.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient/receivedOrganization/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient/receivedOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-16.1.1.2: Элемент ClinicalDocument/informationRecipient[not(intendedRecipient/receivedOrganization/id/@root='1.2.643.5.1.13')]/intendedRecipient/receivedOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-16.1.1.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator">
			<assert test="count(@nullFlavor)=0">У1-17: Элемент ClinicalDocument/legalAuthenticator не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(time)=1">У1-17.1: Элемент legalAuthenticator ДОЛЖЕН содержать один [1..1] элемент time</assert>
			<assert test="count(signatureCode)=1">У1-17.2: Элемент legalAuthenticator ДОЛЖЕН содержать один [1..1] элемент signatureCode</assert>
			<assert test="count(assignedEntity)=1">У1-17.3: Элемент legalAuthenticator ОБЯЗАН содержать один [1..1] элемент assignedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/time">
			<assert test="@nullFlavor='NI'">У1-17.1: Элемент time обязан содержать один атрибут @nullFlavor со значением "NI"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/signatureCode">
			<assert test="@nullFlavor='NI'">У1-17.2: Элемент signatureCode обязан содержать один атрибут @nullFlavor со значением "NI"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity">
			<assert test="count(@nullFlavor)=0">У1-17.3: Элемент ClinicalDocument/legalAuthenticator/assignedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)='.70'])=1">У1-17.3.1: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70)</assert>
			<assert test="count(id[@root='1.2.643.100.3'])=1">У1-17.3.2: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(code)=1">У1-17.3.3: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(addr)=[0,1]">У1-17.3.4: Элемент assignedEntity МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
			<assert test="count(telecom)>=0">У1-17.3.5: Элемент assignedEntity МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(assignedPerson)=1">У1-17.3.6: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент assignedPerson</assert>
			<assert test="count(representedOrganization)=[0,1]">У1-17.3.7: Элемент assignedEntity МОЖЕТ содержать не более одного [0..1] элемента representedOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/id[substring(@root, string-length(@root) - 2)='.70']">
			<assert test="count(@nullFlavor)=0">У1-17.3.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/id[substring(@root, string-length(@root) - 2)='.70'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-17.3.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У1-17.3.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У1-17.3.1: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/id[@root='1.2.643.100.3']">
			<assert test="count(@nullFlavor)=0">У1-17.3.2: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/id[@root='1.2.643.100.3'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root='1.2.643.100.3'">У1-17.3.2: Элемент id обязан содержать один атрибут @root со значением "1.2.643.100.3"</assert>
			<assert test="@extension!=''">У1-17.3.2: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/code">
			<assert test="count(@nullFlavor)=0">У1-17.3.3: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1002','1.2.643.5.1.13.2.1.1.733']">У1-17.3.3: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1002"</assert>
			<assert test="@codeSystemName!=''">У1-17.3.3: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-17.3.3: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-17.3.3: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-17.3.3: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr">
			<assert test="count(@nullFlavor)=0">У1-17.3.4: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-17.3.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-17.3.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-17.3.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-17.3.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-17.3.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-17.3.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-17.3.4.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-17.3.4.2: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-17.3.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-17.3.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-17.3.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-17.3.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-17.3.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-17.3.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-17.3.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-17.3.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-17.3.4.4.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-17.3.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/telecom">
			<assert test="count(@nullFlavor)=0">У1-17.3.5: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-17.3.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-17.3.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-17.3.5: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson">
			<assert test="count(@nullFlavor)=0">У1-17.3.6: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У1-17.3.6.1: Элемент assignedPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name">
			<assert test="count(@nullFlavor)=0">У1-17.3.6.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У1-17.3.6.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У1-17.3.6.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У1-17.3.6.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name/family">
			<assert test="count(@nullFlavor)=0">У1-17.3.6.1.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.6.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name/given">
			<assert test="count(@nullFlavor)=0">У1-17.3.6.1.2: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.6.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У1-17.3.6.1.3: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/assignedPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.6.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization">
			<assert test="count(@nullFlavor)=0">У1-17.3.7: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='ORG'">У1-17.3.7: Элемент representedOrganization обязан содержать один атрибут @classCode со значением "ORG"</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=1">У1-17.3.7.1: Элемент representedOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(name)=1">У1-17.3.7.2: Элемент representedOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)>=0">У1-17.3.7.3: Элемент representedOrganization МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(addr)=[0,1]">У1-17.3.7.4: Элемент representedOrganization МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-17.3.7.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-17.3.7.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-17.3.7.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.2: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.7.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/telecom">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.3: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-17.3.7.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-17.3.7.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-17.3.7.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.4: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-17.3.7.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-17.3.7.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-17.3.7.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-17.3.7.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-17.3.7.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-17.3.7.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.4.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.7.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.4.2: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-17.3.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-17.3.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-17.3.7.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-17.3.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-17.3.7.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-17.3.7.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-17.3.7.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-17.3.7.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-17.3.7.4.4.1: Элемент ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-17.3.7.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/legalAuthenticator/assignedEntity/representedOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-17.3.7.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']">
			<assert test="count(@nullFlavor)=0">У1-18: Элемент ClinicalDocument/participant[@typeCode='IND'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='IND'">У1-18: Элемент participant обязан содержать один атрибут @typeCode со значением "IND"</assert>
			<assert test="count(associatedEntity)=1">У1-18.1: Элемент participant ОБЯЗАН содержать один [1..1] элемент associatedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity">
			<assert test="count(@nullFlavor)=0">У1-18.1: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='GUAR'">У1-18.1: Элемент associatedEntity обязан содержать один атрибут @classCode со значением "GUAR"</assert>
			<assert test="count(code)=1">У1-18.1.1: Элемент associatedEntity ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(identity:DocInfo)=1">У1-18.1.2: Элемент associatedEntity ДОЛЖЕН содержать один [1..1] элемент identity:DocInfo</assert>
			<assert test="count(scopingOrganization)=[0,1]">У1-18.1.3: Элемент associatedEntity МОЖЕТ содержать не более одного [0..1] элемента scopingOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/code">
			<assert test="count(@nullFlavor)=0">У1-18.1.1: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1039'">У1-18.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1039"</assert>
			<assert test="@codeSystemName!=''">У1-18.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-18.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-18.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-18.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo[not(@nullFlavor)]">
			<assert test="count(identity:IdentityDocType)=1">У1-18.1.2.1: Элемент identity:DocInfo ОБЯЗАН содержать один [1..1] элемент identity:IdentityDocType</assert>
			<assert test="count(identity:InsurancePolicyType)=1">У1-18.1.2.2: Элемент identity:DocInfo ДОЛЖЕН содержать один [1..1] элемент identity:InsurancePolicyType</assert>
			<assert test="count(identity:Series)=1">У1-18.1.2.3: Элемент identity:DocInfo ДОЛЖЕН содержать один [1..1] элемент identity:Series</assert>
			<assert test="count(identity:Number)=1">У1-18.1.2.4: Элемент identity:DocInfo ДОЛЖЕН содержать один [1..1] элемент identity:Number</assert>
			<assert test="count(identity:INN)=1">У1-18.1.2.5: Элемент identity:DocInfo ДОЛЖЕН содержать один [1..1] элемент identity:INN</assert>
			<assert test="count(identity:effectiveTime)=1">У1-18.1.2.6: Элемент identity:DocInfo ДОЛЖЕН содержать один [1..1] элемент identity:effectiveTime</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:IdentityDocType">
			<assert test="count(@nullFlavor)=0">У1-18.1.2.1: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:IdentityDocType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.724'">У1-18.1.2.1: Элемент identity:IdentityDocType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.724"</assert>
			<assert test="@codeSystemName!=''">У1-18.1.2.1: Элемент identity:IdentityDocType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-18.1.2.1: Элемент identity:IdentityDocType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-18.1.2.1: Элемент identity:IdentityDocType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-18.1.2.1: Элемент identity:IdentityDocType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:InsurancePolicyType[not(@nullFlavor)]">
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1035'">У1-18.1.2.2: Элемент identity:InsurancePolicyType должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1035"</assert>
			<assert test="@codeSystemName!=''">У1-18.1.2.2: Элемент identity:InsurancePolicyType должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-18.1.2.2: Элемент identity:InsurancePolicyType должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-18.1.2.2: Элемент identity:InsurancePolicyType должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-18.1.2.2: Элемент identity:InsurancePolicyType должен содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:InsurancePolicyType[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:Series[not(@nullFlavor)]">
			<assert test=".!=''">У1-18.1.2.3: Элемент identity:Series должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:Number[not(@nullFlavor)]">
			<assert test=".!=''">У1-18.1.2.4: Элемент identity:Number должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:INN[not(@nullFlavor)]">
			<assert test=".!=''">У1-18.1.2.5: Элемент identity:INN должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:effectiveTime[not(@nullFlavor)]">
			<assert test="count(identity:low)=1">У1-18.1.2.6.1: Элемент identity:effectiveTime ОБЯЗАН содержать один [1..1] элемент identity:low</assert>
			<assert test="count(identity:high)=1">У1-18.1.2.6.2: Элемент identity:effectiveTime ДОЛЖЕН содержать один [1..1] элемент identity:high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:effectiveTime/identity:low">
			<assert test="count(@nullFlavor)=0">У1-18.1.2.6.1: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:effectiveTime/identity:low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-18.1.2.6.1: Элемент identity:low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:effectiveTime/identity:high[not(@nullFlavor)]">
			<assert test="@value!=''">У1-18.1.2.6.2: Элемент identity:high должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/identity:DocInfo/identity:effectiveTime/identity:high[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization">
			<assert test="count(@nullFlavor)=0">У1-18.1.3: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[1])=1">У1-18.1.3.1: Элемент scopingOrganization ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор страховой компании)</assert>
			<assert test="count(identity:SMO)>=0 and count(identity:SMO)&lt;=1">У1-18.1.3.2: Элемент scopingOrganization МОЖЕТ содержать один [0..1] элемент name</assert>
			<assert test="count(name)=1">У1-18.1.3.3: Элемент scopingOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)>=1">У1-18.1.3.4: Элемент scopingOrganization ДОЛЖЕН содержать не менее одного [1..*] элемента telecom</assert>
			<assert test="count(addr)=1">У1-18.1.3.5: Элемент scopingOrganization ДОЛЖЕН содержать один [1..1] элемент addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/id[1][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.99.2.183'">У1-18.1.3.1: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.99.2.183"</assert>
			<assert test="@extension!=''">У1-18.1.3.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/id[1][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-18.1.3.3: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-18.1.3.33: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/identity:SMO">
			<assert test="count(@nullFlavor)=0">У1-18.1.3.2: Элемент identity:SMO не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code!=''">У1-18.1.3.2: Элемент identity:SMO обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.3.44'">У1-18.1.3.2: Элемент identity:SMO обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.3.44"</assert>
			<assert test="@codeSystemVersion!=''">У1-18.1.3.2: Элемент identity:SMO обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@codeSystemName!=''">У1-18.1.3.2: Элемент identity:SMO обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У1-18.1.3.2: Элемент identity:SMO обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[code/@code = '1']/scopingOrganization[id[@nullFlavor]]">
			<assert test="count(identity:SMO)=1">У1-18.1.3.2: Элемент ClinicalDocument/participant/associatedEntity/scopingOrganization/identity:SMO обязан быть представлен.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization[id[1][not(@nullFlavor)]]">
			<assert test="count(identity:SMO)=0">У1-18.1.3.2: Одновременное заполнение элементов identity:SMO и id недопустимо</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/telecom[not(@nullFlavor)]">
			<assert test="count(@use!='')=[0,1]">У1-18.1.3.4: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-18.1.3.4: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-18.1.3.4: Элемент telecom должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/telecom[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr[not(@nullFlavor)]">
			<assert test="count(@use!='')=[0,1]">У1-18.1.3.5: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-18.1.3.5: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-18.1.3.5.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-18.1.3.5.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-18.1.3.5.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-18.1.3.5.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-18.1.3.5.1: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-18.1.3.5.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-18.1.3.5.2: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-18.1.3.5.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-18.1.3.5.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-18.1.3.5.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-18.1.3.5.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-18.1.3.5.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-18.1.3.5.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-18.1.3.5.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-18.1.3.5.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-18.1.3.5.4.1: Элемент ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-18.1.3.5.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='IND']/associatedEntity/scopingOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-18.1.3.5.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']">
			<assert test="count(@nullFlavor)=0">У1-19: Элемент ClinicalDocument/participant[@typeCode='REF'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REF'">У1-19: Элемент participant обязан содержать один атрибут @typeCode со значением "REF"</assert>
			<assert test="count(associatedEntity)=1">У1-19.1: Элемент participant ОБЯЗАН содержать один [1..1] элемент associatedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity">
			<assert test="count(@nullFlavor)=0">У1-19.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='PROV'">У1-19.1: Элемент associatedEntity обязан содержать один атрибут @classCode со значением "PROV"</assert>
			<assert test="count(id[1])=1">У1-19.1.1: Элемент associatedEntity ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор направившего лица в МИС)</assert>
			<assert test="count(id[2])=1">У1-19.1.2: Элемент associatedEntity ДОЛЖЕН содержать один [1..1] элемент id (СНИЛС направившего лица)</assert>
			<assert test="count(code)=1">У1-19.1.3: Элемент associatedEntity ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(addr)=[0,1]">У1-19.1.4: Элемент associatedEntity МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
			<assert test="count(telecom)>=0">У1-19.1.5: Элемент associatedEntity МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(associatedPerson)=1">У1-19.1.6: Элемент associatedEntity ОБЯЗАН содержать один [1..1] элемент associatedPerson</assert>
			<assert test="count(scopingOrganization)=[0,1]">У1-19.1.7: Элемент associatedEntity МОЖЕТ содержать не более одного [0..1] элемента scopingOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У1-19.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У1-19.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У1-19.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.100.3'">У1-19.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.100.3"</assert>
			<assert test="@extension!=''">У1-19.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/code">
			<assert test="count(@nullFlavor)=0">У1-19.1.3: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1002','1.2.643.5.1.13.2.1.1.733']">У1-19.1.3: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1002"</assert>
			<assert test="@codeSystemName!=''">У1-19.1.3: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-19.1.3: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-19.1.3: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-19.1.3: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr">
			<assert test="count(@nullFlavor)=0">У1-19.1.4: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-19.1.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-19.1.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-19.1.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-19.1.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-19.1.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-19.1.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-19.1.4.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-19.1.4.2: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-19.1.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-19.1.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-19.1.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-19.1.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-19.1.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-19.1.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-19.1.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-19.1.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-19.1.4.4.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-19.1.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/telecom">
			<assert test="count(@nullFlavor)=0">У1-19.1.5: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-19.1.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-19.1.5: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-19.1.5: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson">
			<assert test="count(@nullFlavor)=0">У1-19.1.6: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У1-19.1.6.1: Элемент associatedPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name">
			<assert test="count(@nullFlavor)=0">У1-19.1.6.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У1-19.1.6.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У1-19.1.6.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У1-19.1.6.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name/family">
			<assert test="count(@nullFlavor)=0">У1-19.1.6.1.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.6.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name/given">
			<assert test="count(@nullFlavor)=0">У1-19.1.6.1.2: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.6.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У1-19.1.6.1.3: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/associatedPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.6.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization">
			<assert test="count(@nullFlavor)=0">У1-19.1.7: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=1">У1-19.1.7.1: Элемент scopingOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(name)=1">У1-19.1.7.2: Элемент scopingOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)>=0">У1-19.1.7.3: Элемент scopingOrganization МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(addr)=[0,1]">У1-19.1.7.4: Элемент scopingOrganization МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-19.1.7.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-19.1.7.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-19.1.7.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.2: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.7.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/telecom">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.3: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-19.1.7.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-19.1.7.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-19.1.7.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.4: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-19.1.7.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-19.1.7.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-19.1.7.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-19.1.7.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-19.1.7.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-19.1.7.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.4.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.7.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.4.2: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-19.1.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-19.1.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-19.1.7.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-19.1.7.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-19.1.7.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-19.1.7.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-19.1.7.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-19.1.7.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-19.1.7.4.4.1: Элемент ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-19.1.7.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/participant[@typeCode='REF']/associatedEntity/scopingOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-19.1.7.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf">
			<assert test="count(@nullFlavor)=0">У1-20: Элемент ClinicalDocument/inFulfillmentOf не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(order)=1">У1-20.1: Элемент inFulfillmentOf ОБЯЗАН содержать один [1..1] элемент order</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf/order">
			<assert test="count(@nullFlavor)=0">У1-20.1: Элемент ClinicalDocument/inFulfillmentOf/order не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[1])=1">У1-20.1.1: Элемент order ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор направления в МИС)</assert>
			<assert test="count(id[2])=1">У1-20.1.2: Элемент order ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор направления в РЭМД)</assert>
			<assert test="count(code)=1">У1-20.1.3: Элемент order ОБЯЗАН содержать один [1..1] элемент code</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf/order/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У1-20.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У1-20.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У1-20.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf/order/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf/order/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У1-20.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У1-20.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf/order/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/inFulfillmentOf/order/code">
			<assert test="count(@nullFlavor)=0">У1-20.1.3: Элемент ClinicalDocument/inFulfillmentOf/order/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code!=''">У1-20.1.3: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystem!=''">У1-20.1.3: Элемент code обязан содержать один атрибут @codeSystem с не пустым значением</assert>
			<!-- Альтернатива У1-20.1.3 -->
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.1079', '1.2.643.5.1.13.13.11.1522', '1.2.643.5.1.13.2.1.1.646', '1.2.643.5.1.13.13.11.1115', '1.2.643.5.1.13.13.99.2.195']">У1-20.1.3: Элемент code обязан содержать один атрибут @codeSystem с не пустым значением; допустимые значения: "1.2.643.5.1.13.13.99.2.1079","1.2.643.5.1.13.13.11.1522"</assert>
			<assert test="@codeSystemVersion!=''">У1-20.1.3: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@codeSystemName!=''">У1-20.1.3: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У1-20.1.3: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf">
			<assert test="count(@nullFlavor)=0">У1-21: Элемент ClinicalDocument/documentationOf не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(serviceEvent)=1">У1-21.1: Элемент documentationOf ОБЯЗАН содержать один [1..1] элемент serviceEvent</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent">
			<assert test="count(@nullFlavor)=0">У1-21.1: Элемент ClinicalDocument/documentationOf/serviceEvent не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У1-21.1.1: Элемент serviceEvent ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=1">У1-21.1.2: Элемент serviceEvent ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(medService:serviceForm)=[0,1]">У1-21.1.3: Элемент serviceEvent МОЖЕТ содержать не более одного [0..1] элемента medService:serviceForm</assert>
			<assert test="count(medService:serviceType)=[0,1]">У1-21.1.4: Элемент serviceEvent МОЖЕТ содержать не более одного [0..1] элемента medService:serviceType</assert>
			<assert test="count(medService:serviceCond)=[0,1]">У1-21.1.5: Элемент serviceEvent МОЖЕТ содержать не более одного [0..1] элемента medService:serviceCond</assert>
			<assert test="count(performer)>=0">У1-21.1.6: Элемент serviceEvent МОЖЕТ содержать произвольное количество [0..*] элементов performer</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/code">
			<assert test="count(@nullFlavor)=0">У1-21.1.1: Элемент ClinicalDocument/documentationOf/serviceEvent/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='1'">У1-21.1.1: Элемент code обязан содержать один атрибут @code со значением "1"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.726'">У1-21.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.726"</assert>
			<assert test="@codeSystemName!=''">У1-21.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У1-21.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-21.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/effectiveTime">
			<assert test="count(@nullFlavor)=0">У1-21.1.2: Элемент ClinicalDocument/documentationOf/serviceEvent/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=1">У1-21.1.2.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=1">У1-21.1.2.2: Элемент effectiveTime ДОЛЖЕН содержать один [1..1] элемент high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У1-21.1.2.1: Элемент ClinicalDocument/documentationOf/serviceEvent/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-21.1.2.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/effectiveTime/high[not(@nullFlavor)]">
			<assert test="@value!=''">У1-21.1.2.2: Элемент high должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/effectiveTime/high[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/medService:serviceForm">
			<assert test="count(@nullFlavor)=0">У1-21.1.3: Элемент ClinicalDocument/documentationOf/serviceEvent/medService:serviceForm не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1551','1.2.643.5.1.13.2.1.1.568','1.2.643.5.1.13.13.99.2.377']">У1-21.1.3: Элемент medService:serviceForm обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1551"</assert>
			<assert test="@codeSystemName!=''">У1-21.1.3: Элемент medService:serviceForm обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-21.1.3: Элемент medService:serviceForm обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-21.1.3: Элемент medService:serviceForm обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-21.1.3: Элемент medService:serviceForm обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/medService:serviceType">
			<assert test="count(@nullFlavor)=0">У1-21.1.4: Элемент ClinicalDocument/documentationOf/serviceEvent/medService:serviceType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1034'">У1-21.1.4: Элемент medService:serviceType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1034"</assert>
			<assert test="@codeSystemName!=''">У1-21.1.4: Элемент medService:serviceType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-21.1.4: Элемент medService:serviceType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-21.1.4: Элемент medService:serviceType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-21.1.4: Элемент medService:serviceType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/medService:serviceCond">
			<assert test="count(@nullFlavor)=0">У1-21.1.5: Элемент ClinicalDocument/documentationOf/serviceEvent/medService:serviceCond не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.322','1.2.643.5.1.13.2.1.1.103']">У1-21.1.5: Элемент medService:serviceCond обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.322"</assert>
			<assert test="@codeSystemName!=''">У1-21.1.5: Элемент medService:serviceCond обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-21.1.5: Элемент medService:serviceCond обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-21.1.5: Элемент medService:serviceCond обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-21.1.5: Элемент medService:serviceCond обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer">
			<assert test="count(@nullFlavor)=0">У1-21.1.6: Элемент ClinicalDocument/documentationOf/serviceEvent/performer не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode!=''">У1-21.1.6: Элемент performer обязан содержать один атрибут @typeCode с не пустым значением</assert>
			<!-- Альтернатива У1-21.1.6 -->
			<assert test="@typeCode=['PPRF','SPRF']">У1-21.1.6: Элемент performer обязан содержать один атрибут @typeCode с не пустым значением; допустимые значения: 'PPRF','SPRF'</assert>
			<assert test="count(assignedEntity)=1">У1-21.1.6.1: Элемент performer ОБЯЗАН содержать один [1..1] элемент assignedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[1])=1">У1-21.1.6.1.1: Элемент assignedEntity ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор участника документируемого события в МИС)</assert>
			<assert test="count(code)=1">У1-21.1.6.1.2: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(telecom)>=0">У1-21.1.6.1.3: Элемент assignedEntity МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(assignedPerson)=1">У1-21.1.6.1.4: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент assignedPerson</assert>
			<assert test="count(representedOrganization)=[0,1]">У1-21.1.6.1.5: Элемент assignedEntity МОЖЕТ содержать не более одного [0..1] элемента representedOrganization</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У1-21.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У1-21.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У1-21.1.6.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/code">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.2: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1002','1.2.643.5.1.13.2.1.1.733']">У1-21.1.6.1.2: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1002"</assert>
			<assert test="@codeSystemName!=''">У1-21.1.6.1.2: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-21.1.6.1.2: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-21.1.6.1.2: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-21.1.6.1.2: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/telecom">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.3: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-21.1.6.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-21.1.6.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-21.1.6.1.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.4: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У1-21.1.6.1.4.1: Элемент assignedPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.4.1: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У1-21.1.6.1.4.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У1-21.1.6.1.4.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У1-21.1.6.1.4.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name/family">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.4.1.1: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-21.1.6.1.4.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name/given">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.4.1.2: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-21.1.6.1.4.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.4.1.3: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/assignedPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-21.1.6.1.4.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='ORG'">У1-21.1.6.1.5: Элемент representedOrganization обязан содержать один атрибут @classCode со значением "ORG"</assert>
			<assert test="count(id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')])=1">У1-21.1.6.1.5.1: Элемент representedOrganization ОБЯЗАН содержать один [1..1] элемент id</assert>
			<assert test="count(name)=1">У1-21.1.6.1.5.2: Элемент representedOrganization ОБЯЗАН содержать один [1..1] элемент name</assert>
			<assert test="count(telecom)>=0">У1-21.1.6.1.5.3: Элемент representedOrganization МОЖЕТ содержать произвольное количество [0..*] элементов telecom</assert>
			<assert test="count(addr)=[0,1]">У1-21.1.6.1.5.4: Элемент representedOrganization МОЖЕТ содержать не более одного [0..1] элемента addr</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')]">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.1: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/id[not(@root='1.2.643.100.3')][not(@root='1.2.643.5.1.13.2.1.1.1504.101')][not(@root='1.2.643.5.1.13.13.17.1.1')] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-21.1.6.1.5.1: Элемент id обязан содержать один атрибут @root с не пустым значением</assert>
			<assert test="count(@extension!='')=[0,1]">У1-21.1.6.1.5.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
			<assert test="if (@extension) then @extension!='' else(not(@extension))">У1-21.1.6.1.5.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/name">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.2: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-21.1.6.1.5.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/telecom">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.3: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-21.1.6.1.5.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-21.1.6.1.5.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У1-21.1.6.1.5.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.4: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У1-21.1.6.1.5.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У1-21.1.6.1.5.4: Элемент addr должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="count(streetAddressLine)=1">У1-21.1.6.1.5.4.1: Элемент addr ОБЯЗАН содержать один [1..1] элемент streetAddressLine</assert>
			<assert test="count(address:stateCode)=1">У1-21.1.6.1.5.4.2: Элемент addr ОБЯЗАН содержать один [1..1] элемент address:stateCode</assert>
			<assert test="count(postalCode)=1">У1-21.1.6.1.5.4.3: Элемент addr ДОЛЖЕН содержать один [1..1] элемент postalCode</assert>
			<assert test="count(fias:Address)=1">У1-21.1.6.1.5.4.4: Элемент addr ДОЛЖЕН содержать один [1..1] элемент fias:Address</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/streetAddressLine">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.4.1: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/streetAddressLine не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-21.1.6.1.5.4.1: Элемент streetAddressLine должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/address:stateCode">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.4.2: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/address:stateCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.206','1.2.643.5.1.13.13.11.1093']">У1-21.1.6.1.5.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.206"</assert>
			<assert test="@codeSystemName!=''">У1-21.1.6.1.5.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-21.1.6.1.5.4.2: Элемент address:stateCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-21.1.6.1.5.4.2: Элемент address:stateCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-21.1.6.1.5.4.2: Элемент address:stateCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/postalCode[not(@nullFlavor)]">
			<assert test=".!=''">У1-21.1.6.1.5.4.3: Элемент postalCode должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/fias:Address[not(@nullFlavor)]">
			<assert test="count(fias:AOGUID)=1">У1-21.1.6.1.5.4.4.1: Элемент fias:Address ОБЯЗАН содержать один [1..1] элемент fias:AOGUID</assert>
			<assert test="count(fias:HOUSEGUID)=1">У1-21.1.6.1.5.4.4.2: Элемент fias:Address ДОЛЖЕН содержать один [1..1] элемент fias:HOUSEGUID</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/fias:Address/fias:AOGUID">
			<assert test="count(@nullFlavor)=0">У1-21.1.6.1.5.4.4.1: Элемент ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/fias:Address/fias:AOGUID не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У1-21.1.6.1.5.4.4.1: Элемент fias:AOGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent/performer/assignedEntity/representedOrganization/addr/fias:Address/fias:HOUSEGUID[not(@nullFlavor)]">
			<assert test=".!=''">У1-21.1.6.1.5.4.4.2: Элемент fias:HOUSEGUID должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf">
			<assert test="count(@nullFlavor)=0">У1-22: Элемент ClinicalDocument/componentOf не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(encompassingEncounter)=1">У1-22.1: Элемент componentOf ОБЯЗАН содержать один [1..1] элемент encompassingEncounter</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter">
			<assert test="count(@nullFlavor)=0">У1-22.1: Элемент ClinicalDocument/componentOf/encompassingEncounter не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)='.15'])=1">У1-22.1.1: Элемент encompassingEncounter ОБЯЗАН содержать один [1..1] элемент id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.15)</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)=['.16','.17']])=[0,1]">У1-22.1.2: Элемент encompassingEncounter МОЖЕТ содержать не более одного [0..1] элемента id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.16; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.17)</assert>
			<assert test="count(code)=[0,1]">У1-22.1.3: Элемент encompassingEncounter МОЖЕТ содержать не более одного [0..1] элемента code</assert>
			<assert test="count(medService:DocType)=[0,1]">У1-22.1.4: Элемент encompassingEncounter МОЖЕТ содержать не более одного [0..1] элемента medService:DocType</assert>
			<assert test="count(effectiveTime)=[0,1]">У1-22.1.5: Элемент encompassingEncounter МОЖЕТ содержать не более одного [0..1] элемента effectiveTime</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/id[substring(@root, string-length(@root) - 2)='.15']">
			<assert test="count(@nullFlavor)=0">У1-22.1.1: Элемент ClinicalDocument/componentOf/encompassingEncounter/id[substring(@root, string-length(@root) - 2)='.15'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-22.1.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.15</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.15$')">У1-22.1.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.15</assert>
			<assert test="@extension!=''">У1-22.1.1: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/id[substring(@root, string-length(@root) - 2)=['.16','.17']]">
			<assert test="count(@nullFlavor)=0">У1-22.1.2: Элемент ClinicalDocument/componentOf/encompassingEncounter/id[substring(@root, string-length(@root) - 2)=['.16','.17']] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У1-22.1.2: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.16; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.17</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.(16|17)$')">У1-22.1.2: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.16; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.17</assert>
			<assert test="@extension!=''">У1-22.1.2: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/code">
			<assert test="count(@nullFlavor)=0">У1-22.1.3: Элемент ClinicalDocument/componentOf/encompassingEncounter/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.723'">У1-22.1.3: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.723"</assert>
			<assert test="@codeSystemName!=''">У1-22.1.3: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-22.1.3: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-22.1.3: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-22.1.3: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У1-22.1.4 -->
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter[code/@code='3']">
			<assert test="count(medService:DocType)=1">У1-22.1.4: Элемент encompassingEncounter МОЖЕТ содержать не более одного [0..1] элемента medService:DocType; Если атрибут code/@code представлен со значением '3', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У1-22.1.4 -->
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter[code/@code!='3']">
			<assert test="count(medService:DocType)=0">У1-22.1.4: Элемент encompassingEncounter МОЖЕТ содержать не более одного [0..1] элемента medService:DocType; Если атрибут code/@code представлен со значением '3', то элемент обязан быть представлен. Если иначе, то элемент должен отсутствовать</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/medService:DocType">
			<assert test="count(@nullFlavor)=0">У1-22.1.4: Элемент ClinicalDocument/componentOf/encompassingEncounter/medService:DocType не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1522','1.2.643.5.1.13.2.1.1.646','1.2.643.5.1.13.13.11.1115','1.2.643.5.1.13.13.99.2.195']">У1-22.1.4: Элемент medService:DocType обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1522"</assert>
			<assert test="@codeSystemName!=''">У1-22.1.4: Элемент medService:DocType обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У1-22.1.4: Элемент medService:DocType обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У1-22.1.4: Элемент medService:DocType обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У1-22.1.4: Элемент medService:DocType обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/effectiveTime">
			<assert test="count(@nullFlavor)=0">У1-22.1.5: Элемент ClinicalDocument/componentOf/encompassingEncounter/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=1">У1-22.1.5.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=[0,1]">У1-22.1.5.2: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У1-22.1.5.1: Элемент ClinicalDocument/componentOf/encompassingEncounter/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-22.1.5.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/componentOf/encompassingEncounter/effectiveTime/high">
			<assert test="count(@nullFlavor)=0">У1-22.1.5.2: Элемент ClinicalDocument/componentOf/encompassingEncounter/effectiveTime/high не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У1-22.1.5.2: Элемент high обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component">
			<assert test="count(@nullFlavor)=0">У1-23: Элемент ClinicalDocument/component не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(structuredBody)=1">У1-23.1: Элемент component ОБЯЗАН содержать один [1..1] элемент structuredBody</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody">
			<assert test="count(@nullFlavor)=0">У1-23.1: Элемент ClinicalDocument/component/structuredBody не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(component[section/code/@code='DOCINFO'])=1">У2-1: Элемент structuredBody ОБЯЗАН содержать один [1..1] элемент component</assert>
			<assert test="count(component[section/code/@code='BENEFITS'])=[0,1]">У2-2: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='COMPLNTS'])=[0,1]">У2-3: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='ANAM'])=1">У2-4: Элемент structuredBody ОБЯЗАН содержать один [1..1] элемент component</assert>
			<assert test="count(component[section/code/@code='LANAM'])=1">У2-5: Элемент structuredBody ОБЯЗАН содержать один [1..1] элемент component</assert>
			<assert test="count(component[section/code/@code='RESCONS'])=[0,1]">У2-6: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='CONSILIUMDECISION'])=[0,1]">У2-7: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='COMMISSION'])=[0,1]">У2-8: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='RESINSTR'])=[0,1]">У2-9: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='RESLAB'])=[0,1]">У2-10: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='GISTRESULT'])=[0,1]">У2-11: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='SUR'])=[0,1]">У2-12: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='TRANSFUSINFO'])=[0,1]">У2-13: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='ELSEPROCEDURE'])=[0,1]">У2-14: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='DRUG'])=[0,1]">У2-15: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='VITALPARAM'])=[0,1]">У2-16: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='SCORES'])=[0,1]">У2-17: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='DGN'])=1">У2-18: Элемент structuredBody ОБЯЗАН содержать один [1..1] элемент component</assert>
			<assert test="count(component[section/code/@code='REGIME'])=[0,1]">У2-19: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='SERVICES'])=[0,1]">У2-20: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='LINKDOCS'])=[0,1]">У2-21: Элемент structuredBody МОЖЕТ содержать не более одного [0..1] элемента component</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']">
			<assert test="count(@nullFlavor)=0">У2-1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-1.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section">
			<assert test="count(@nullFlavor)=0">У2-1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-1.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-1.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='800'])=1">У3-1: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
			<assert test="count(entry[observation/code/@code='801'])=[0,1]">У3-2: Элемент section МОЖЕТ содержать не более одного [0..1] элемента entry</assert>
			<assert test="count(entry[observation/code/@code='7003'])=[0,1]">У3-3: Элемент section МОЖЕТ содержать не более одного [0..1] элемента entry</assert>
			<assert test="count(entry[observation/code/@code='804'])=1">У3-4: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
			<assert test="count(entry[observation/code/@code='836'])=[0,1]">У3-5: Элемент section МОЖЕТ содержать не более одного [0..1] элемента entry</assert>
			<assert test="count(entry[observation/code/@code='806'])=1">У3-6: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
			<assert test="count(entry[observation/code/@code='808'])>=0">У3-7: Элемент section МОЖЕТ содержать произвольное количество [0..*] элементов entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/code">
			<assert test="count(@nullFlavor)=0">У2-1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='DOCINFO'">У2-1.1.1: Элемент code обязан содержать один атрибут @code со значением "DOCINFO"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-1.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-1.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-1.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-1.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/title">
			<assert test="count(@nullFlavor)=0">У2-1.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-1.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']">
			<assert test="count(@nullFlavor)=0">У3-1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-1.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']/observation">
			<assert test="count(@nullFlavor)=0">У3-1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-1.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-1.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-1.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-1.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='800'">У3-1.1.1: Элемент code обязан содержать один атрибут @code со значением "800"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-1.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-1.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-1.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-1.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-1.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='800']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-1.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1007','1.2.643.5.1.13.2.1.1.109']">У3-1.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1007"</assert>
			<assert test="@codeSystemName!=''">У3-1.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-1.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-1.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-1.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']">
			<assert test="count(@nullFlavor)=0">У3-2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-2.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']/observation">
			<assert test="count(@nullFlavor)=0">У3-2.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-2.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-2.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-2.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-2.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-2.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='801'">У3-2.1.1: Элемент code обязан содержать один атрибут @code со значением "801"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-2.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-2.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-2.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-2.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-2.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='801']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-2.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1008'">У3-2.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1008"</assert>
			<assert test="@codeSystemName!=''">У3-2.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-2.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-2.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-2.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']">
			<assert test="count(@nullFlavor)=0">У3-3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-3.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']/observation">
			<assert test="count(@nullFlavor)=0">У3-3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-3.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-3.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-3.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-3.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-3.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7003'">У3-3.1.1: Элемент code обязан содержать один атрибут @code со значением "7003"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-3.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-3.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-3.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-3.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-3.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='7003']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-3.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.688'">У3-3.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.688"</assert>
			<assert test="@codeSystemName!=''">У3-3.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-3.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-3.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-3.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']">
			<assert test="count(@nullFlavor)=0">У3-4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-4.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']/observation">
			<assert test="count(@nullFlavor)=0">У3-4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='804'">У3-4.1.1: Элемент code обязан содержать один атрибут @code со значением "804"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='804']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1006','1.2.643.5.1.13.2.1.1.111']">У3-4.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1006"</assert>
			<assert test="@codeSystemName!=''">У3-4.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-4.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-4.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-4.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']">
			<assert test="count(@nullFlavor)=0">У3-5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-5.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']/observation">
			<assert test="count(@nullFlavor)=0">У3-5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='836'">У3-5.1.1: Элемент code обязан содержать один атрибут @code со значением "836"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='836']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-5.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-5.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']">
			<assert test="count(@nullFlavor)=0">У3-6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-6.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']/observation">
			<assert test="count(@nullFlavor)=0">У3-6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-6.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-6.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-6.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-6.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='806'">У3-6.1.1: Элемент code обязан содержать один атрибут @code со значением "806"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='ST'">У3-6.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-6.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='806']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='ST'">У3-6.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']">
			<assert test="count(@nullFlavor)=0">У3-7: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-7.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation">
			<assert test="count(@nullFlavor)=0">У3-7.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-7.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-7.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-7.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-7.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-7.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='808'">У3-7.1.1: Элемент code обязан содержать один атрибут @code со значением "808"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-7.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-7.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-7.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-7.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='CD'">У3-7.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1473'">У3-7.1.2: Элемент value должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1473"</assert>
			<assert test="@codeSystemName!=''">У3-7.1.2: Элемент value должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-7.1.2: Элемент value должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-7.1.2: Элемент value должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-7.1.2: Элемент value должен содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="count(originalText)=[0,1]">У3-7.1.2.1: Элемент value МОЖЕТ содержать не более одного [0..1] элемента originalText</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='CD'">У3-7.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
			<!-- Альтернатива У3-7.1.2 -->
			<assert test="@nullFlavor='OTH'">У3-7.1.2: Допустимые значения для атрибута  nullFlavor: 'OTH'</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-7.1.2.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/value[@nullFlavor='OTH']">
			<assert test="count(originalText)=1">У3-7.1.2.1: Элемент value МОЖЕТ содержать не более одного [0..1] элемента originalText; Если атрибут value/@nullFlavor представлен со значением 'OTH', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/value/originalText">
			<assert test="count(@nullFlavor)=0">У3-7.1.2.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DOCINFO']/section/entry[observation/code/@code='808']/observation/value/originalText не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-7.1.2.1: Элемент originalText должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']">
			<assert test="count(@nullFlavor)=0">У2-2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-2.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section">
			<assert test="count(@nullFlavor)=0">У2-2.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-2.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-2.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='811'])>=1">У3-8: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/code">
			<assert test="count(@nullFlavor)=0">У2-2.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='BENEFITS'">У2-2.1.1: Элемент code обязан содержать один атрибут @code со значением "BENEFITS"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-2.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-2.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-2.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-2.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/title">
			<assert test="count(@nullFlavor)=0">У2-2.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-2.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']">
			<assert test="count(@nullFlavor)=0">У3-8: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-8.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']/observation">
			<assert test="count(@nullFlavor)=0">У3-8.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-8.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-8.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-8.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-8.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-8.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='811'">У3-8.1.1: Элемент code обязан содержать один атрибут @code со значением "811"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-8.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-8.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-8.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-8.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-8.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='BENEFITS']/section/entry[observation/code/@code='811']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-8.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.541'">У3-8.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.541"</assert>
			<assert test="@codeSystemName!=''">У3-8.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-8.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-8.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-8.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']">
			<assert test="count(@nullFlavor)=0">У2-3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-3.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section">
			<assert test="count(@nullFlavor)=0">У2-3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-3.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-3.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='835'])=1">У3-9: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/code">
			<assert test="count(@nullFlavor)=0">У2-3.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='COMPLNTS'">У2-3.1.1: Элемент code обязан содержать один атрибут @code со значением "COMPLNTS"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-3.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-3.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-3.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-3.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/title">
			<assert test="count(@nullFlavor)=0">У2-3.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-3.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']">
			<assert test="count(@nullFlavor)=0">У3-9: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-9.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']/observation">
			<assert test="count(@nullFlavor)=0">У3-9.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-9.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-9.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-9.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-9.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-9.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='835'">У3-9.1.1: Элемент code обязан содержать один атрибут @code со значением "835"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-9.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-9.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-9.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-9.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-9.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMPLNTS']/section/entry[observation/code/@code='835']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-9.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-9.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']">
			<assert test="count(@nullFlavor)=0">У2-4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-4.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section">
			<assert test="count(@nullFlavor)=0">У2-4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-4.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-4.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='7006'])=1">У3-10: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/code">
			<assert test="count(@nullFlavor)=0">У2-4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='ANAM'">У2-4.1.1: Элемент code обязан содержать один атрибут @code со значением "ANAM"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/title">
			<assert test="count(@nullFlavor)=0">У2-4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-4.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']">
			<assert test="count(@nullFlavor)=0">У3-10: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-10.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']/observation">
			<assert test="count(@nullFlavor)=0">У3-10.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-10.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-10.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-10.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-10.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-10.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7006'">У3-10.1.1: Элемент code обязан содержать один атрибут @code со значением "7006"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-10.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-10.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-10.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-10.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='ST'">У3-10.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-10.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ANAM']/section/entry[observation/code/@code='7006']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='ST'">У3-10.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']">
			<assert test="count(@nullFlavor)=0">У2-5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-5.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section">
			<assert test="count(@nullFlavor)=0">У2-5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-5.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-5.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='7006'])=1">У3-11: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
			<assert test="count(component[section/code/@code='SOCANAM'])=[0,1]">У2-5.1.3: Элемент section МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='OBSTETRICANAMN'])=[0,1]">У2-5.1.4: Элемент section МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='ALL'])=[0,1]">У2-5.1.5: Элемент section МОЖЕТ содержать не более одного [0..1] элемента component</assert>
			<assert test="count(component[section/code/@code='EPIDEM'])=[0,1]">У2-5.1.6: Элемент section МОЖЕТ содержать не более одного [0..1] элемента component</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/code">
			<assert test="count(@nullFlavor)=0">У2-5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='LANAM'">У2-5.1.1: Элемент code обязан содержать один атрибут @code со значением "LANAM"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/title">
			<assert test="count(@nullFlavor)=0">У2-5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-5.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']">
			<assert test="count(@nullFlavor)=0">У3-11: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-11.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']/observation">
			<assert test="count(@nullFlavor)=0">У3-11.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-11.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-11.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-11.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-11.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-11.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7006'">У3-11.1.1: Элемент code обязан содержать один атрибут @code со значением "7006"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-11.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-11.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-11.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-11.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='ST'">У3-11.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-11.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/entry[observation/code/@code='7006']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='ST'">У3-11.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']">
			<assert test="count(@nullFlavor)=0">У2-5.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-5.1.3.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section">
			<assert test="count(@nullFlavor)=0">У2-5.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-5.1.3.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-5.1.3.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='814'])>=0">У3-12: Элемент section МОЖЕТ содержать произвольное количество [0..*] элементов entry</assert>
			<assert test="count(entry[observation/code/@code='812'])>=0">У3-13: Элемент section МОЖЕТ содержать произвольное количество [0..*] элементов entry</assert>
			<assert test="count(entry[observation/code/@code='9052'])>=0">У3-14: Элемент section МОЖЕТ содержать произвольное количество [0..*] элементов entry</assert>
			<assert test="count(entry[observation/code/@code='9053'])>=0">У3-15: Элемент section МОЖЕТ содержать произвольное количество [0..*] элементов entry</assert>
			<assert test="count(entry[observation/code/@code='12524'])=[0,1]">У3-16: Элемент section МОЖЕТ содержать не более одного [0..1] элемента entry</assert>
			<assert test="count(entry[observation/code/@code='12006'])=[0,1]">У3-17: Элемент section МОЖЕТ содержать не более одного [0..1] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/code">
			<assert test="count(@nullFlavor)=0">У2-5.1.3.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='SOCANAM'">У2-5.1.3.1.1: Элемент code обязан содержать один атрибут @code со значением "SOCANAM"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-5.1.3.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-5.1.3.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-5.1.3.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-5.1.3.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/title">
			<assert test="count(@nullFlavor)=0">У2-5.1.3.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-5.1.3.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']">
			<assert test="count(@nullFlavor)=0">У3-12: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-12.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=1">У3-12.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-12.1.3: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='8043'])=[0,1]">У3-12.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='815'])=[0,1]">У3-12.1.5: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='8040'])=[0,1]">У3-12.1.6: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='4058'])>=0">У3-12.1.7: Элемент observation МОЖЕТ содержать произвольное количество [0..*] элементов entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='814'">У3-12.1.1: Элемент code обязан содержать один атрибут @code со значением "814"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/effectiveTime[not(@nullFlavor)]">
			<assert test="count(low)=1">У3-12.1.2.1: Элемент effectiveTime ДОЛЖЕН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=1">У3-12.1.2.2: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/effectiveTime/low[not(@nullFlavor)]">
			<assert test="@value!=''">У3-12.1.2.1: Элемент low должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/effectiveTime/low[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/effectiveTime/high">
			<assert test="count(@nullFlavor)=0">У3-12.1.2.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/effectiveTime/high не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-12.1.2.2: Элемент high обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='CD'">У3-12.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1053','1.2.643.5.1.13.2.1.1.702']">У3-12.1.3: Элемент value должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1053"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.3: Элемент value должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-12.1.3: Элемент value должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.3: Элемент value должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.3: Элемент value должен содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='CD'">У3-12.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']">
			<assert test="count(@nullFlavor)=0">У3-12.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-12.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-12.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-12.1.4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8043'">У3-12.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "8043"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-12.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8043']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='BL'">У3-12.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "BL"</assert>
			<assert test="@value!=''">У3-12.1.4.1.2: Элемент value обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']">
			<assert test="count(@nullFlavor)=0">У3-12.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-12.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-12.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-12.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='815'">У3-12.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "815"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-12.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='815']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-12.1.5.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1041'">У3-12.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1041"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-12.1.5.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.5.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']">
			<assert test="count(@nullFlavor)=0">У3-12.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-12.1.6: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-12.1.6.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1.6.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1.6.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.6.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-12.1.6.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=1">У3-12.1.6.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="(count(entryRelationship[observation/code/@code='8041'])&gt;=0) and (count(entryRelationship[observation/code/@code='8041'])&lt;4)">У3-12.1.6.1.4: Элемент observation МОЖЕТ содержать не более трёх [0..3] элементов entryRelationship</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-12.1.6.1.2 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation[value/@code='19']">
			<assert test="count(text)=1">У3-12.1.6.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text; Если атрибут value/@code представлен со значением '19', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8040'">У3-12.1.6.1.1: Элемент code обязан содержать один атрибут @code со значением "8040"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-12.1.6.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-12.1.6.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1474','1.2.643.5.1.13.2.1.1.169']">У3-12.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1474"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-12.1.6.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.6.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-12.1.6.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-12.1.6.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1.6.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1.6.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.6.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-12.1.6.1.4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8041'">У3-12.1.6.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "8041"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.6.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.6.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.6.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.6.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-12.1.6.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='8040']/observation/entryRelationship[observation/code/@code='8041']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-12.1.6.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.686'">У3-12.1.6.1.4.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.686"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.6.1.4.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-12.1.6.1.4.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.6.1.4.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.6.1.4.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']">
			<assert test="count(@nullFlavor)=0">У3-12.1.7: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-12.1.7: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-12.1.7.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1.7.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1.7.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.7.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=1">У3-12.1.7.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-12.1.7.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='4083'])=1">У3-12.1.7.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='4058'">У3-12.1.7.1.1: Элемент code обязан содержать один атрибут @code со значением "4058"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.7.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.7.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.7.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.7.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/effectiveTime[not(@nullFlavor)]">
			<assert test="@value!=''">У3-12.1.7.1.2: Элемент effectiveTime должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/effectiveTime[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='PQ'">У3-12.1.7.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "PQ"</assert>
			<assert test="@unit='%'">У3-12.1.7.1.3: Элемент value обязан содержать один атрибут @unit со значением "%"</assert>
			<assert test="@value!=''">У3-12.1.7.1.3: Элемент value обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="count(translation)=1">У3-12.1.7.1.3.1: Элемент value ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/value/translation">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/value/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='53'">У3-12.1.7.1.3.1: Элемент translation обязан содержать один атрибут @code со значением "53"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-12.1.7.1.3.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.7.1.3.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.7.1.3.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@value!=''">У3-12.1.7.1.3.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.7.1.3.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-12.1.7.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-12.1.7.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']/observation">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-12.1.7.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-12.1.7.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-12.1.7.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-12.1.7.1.4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='4083'">У3-12.1.7.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "4083"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-12.1.7.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.7.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.7.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.7.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-12.1.7.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='814']/observation/entryRelationship[observation/code/@code='4058']/observation/entryRelationship[observation/code/@code='4083']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-12.1.7.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.325'">У3-12.1.7.1.4.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.325"</assert>
			<assert test="@codeSystemName!=''">У3-12.1.7.1.4.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-12.1.7.1.4.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-12.1.7.1.4.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-12.1.7.1.4.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']">
			<assert test="count(@nullFlavor)=0">У3-13: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-13.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']/observation">
			<assert test="count(@nullFlavor)=0">У3-13.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-13.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-13.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-13.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-13.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-13.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='812'">У3-13.1.1: Элемент code обязан содержать один атрибут @code со значением "812"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-13.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-13.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-13.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-13.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-13.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='812']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-13.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1059','1.2.643.5.1.13.2.1.1.713']">У3-13.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1059"</assert>
			<assert test="@codeSystemName!=''">У3-13.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-13.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-13.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-13.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']">
			<assert test="count(@nullFlavor)=0">У3-14: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-14.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']/observation">
			<assert test="count(@nullFlavor)=0">У3-14.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-14.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-14.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-14.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-14.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-14.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='9052'">У3-14.1.1: Элемент code обязан содержать один атрибут @code со значением "9052"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-14.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-14.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-14.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-14.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-14.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9052']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-14.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1060','1.2.643.5.1.13.2.1.1.714']">У3-14.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1060"</assert>
			<assert test="@codeSystemName!=''">У3-14.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-14.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-14.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-14.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']">
			<assert test="count(@nullFlavor)=0">У3-15: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-15.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']/observation">
			<assert test="count(@nullFlavor)=0">У3-15.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-15.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-15.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-15.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-15.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-15.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='9053'">У3-15.1.1: Элемент code обязан содержать один атрибут @code со значением "9053"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-15.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-15.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-15.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-15.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-15.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='9053']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-15.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1058','1.2.643.5.1.13.2.1.1.701']">У3-15.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1058"</assert>
			<assert test="@codeSystemName!=''">У3-15.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-15.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-15.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-15.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']">
			<assert test="count(@nullFlavor)=0">У3-16: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-16.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation">
			<assert test="count(@nullFlavor)=0">У3-16.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-16.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-16.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-16.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-16.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=1">У3-16.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-16.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12524'">У3-16.1.1: Элемент code обязан содержать один атрибут @code со значением "12524"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-16.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-16.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-16.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-16.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-16.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-16.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-16.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12524']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-16.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1038'">У3-16.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1038"</assert>
			<assert test="@codeSystemName!=''">У3-16.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-16.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-16.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-16.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']">
			<assert test="count(@nullFlavor)=0">У3-17: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-17.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation">
			<assert test="count(@nullFlavor)=0">У3-17.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-17.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-17.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-17.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=1">У3-17.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-17.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-17.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12006'">У3-17.1.1: Элемент code обязан содержать один атрибут @code со значением "12006"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-17.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-17.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-17.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-17.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-17.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=1">У3-17.1.2.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=1">У3-17.1.2.2: Элемент effectiveTime ДОЛЖЕН содержать один [1..1] элемент high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У3-17.1.2.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-17.1.2.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/effectiveTime/high[not(@nullFlavor)]">
			<assert test="@value!=''">У3-17.1.2.2: Элемент high должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/effectiveTime/high[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-17.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='SOCANAM']/section/entry[observation/code/@code='12006']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-17.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1044','1.2.643.5.1.13.2.1.1.121']">У3-17.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1044"</assert>
			<assert test="@codeSystemName!=''">У3-17.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-17.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-17.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-17.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']">
			<assert test="count(@nullFlavor)=0">У2-5.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-5.1.4.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section">
			<assert test="count(@nullFlavor)=0">У2-5.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-5.1.4.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-5.1.4.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='7006'])=1">У3-18: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
			<assert test="count(entry[observation/code/@code='12310'])=1">У3-19: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/code">
			<assert test="count(@nullFlavor)=0">У2-5.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='OBSTETRICANAMN'">У2-5.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "OBSTETRICANAMN"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-5.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-5.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-5.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-5.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/title">
			<assert test="count(@nullFlavor)=0">У2-5.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-5.1.4.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']">
			<assert test="count(@nullFlavor)=0">У3-18: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-18.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']/observation">
			<assert test="count(@nullFlavor)=0">У3-18.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-18.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-18.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-18.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-18.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-18.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7006'">У3-18.1.1: Элемент code обязан содержать один атрибут @code со значением "7006"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-18.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-18.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-18.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-18.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='ST'">У3-18.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-18.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='7006']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='ST'">У3-18.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']">
			<assert test="count(@nullFlavor)=0">У3-19: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-19.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']/observation">
			<assert test="count(@nullFlavor)=0">У3-19.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-19.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-19.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-19.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-19.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-19.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12310'">У3-19.1.1: Элемент code обязан содержать один атрибут @code со значением "12310"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-19.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-19.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-19.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-19.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='INT'">У3-19.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "INT"</assert>
			<assert test="@value!=''">У3-19.1.2: Элемент value должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='OBSTETRICANAMN']/section/entry[observation/code/@code='12310']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='INT'">У3-19.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "INT"</assert>
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']">
			<assert test="count(@nullFlavor)=0">У2-5.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-5.1.5.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section">
			<assert test="count(@nullFlavor)=0">У2-5.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-5.1.5.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-5.1.5.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='11036'])>=1">У3-20: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/code">
			<assert test="count(@nullFlavor)=0">У2-5.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='ALL'">У2-5.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "ALL"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-5.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-5.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-5.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-5.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/title">
			<assert test="count(@nullFlavor)=0">У2-5.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-5.1.5.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']">
			<assert test="count(@nullFlavor)=0">У3-20: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-20.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation">
			<assert test="count(@nullFlavor)=0">У3-20.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-20.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-20.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-20.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-20.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-20.1.3: Элемент observation ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-20.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(participant[@typeCode='IND'])=1">У3-20.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент participant</assert>
			<assert test="count(entryRelationship[observation/code/@code='12328'])>=1">У3-20.1.6: Элемент observation ОБЯЗАН содержать не менее одного [1..*] элемента entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-20.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='11036'">У3-20.1.1: Элемент code обязан содержать один атрибут @code со значением "11036"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-20.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-20.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-20.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-20.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-20.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-20.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/effectiveTime[not(@nullFlavor)]">
			<assert test="@value!=''">У3-20.1.3: Элемент effectiveTime должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/effectiveTime[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-20.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-20.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1064','1.2.643.5.1.13.2.1.1.709']">У3-20.1.4: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1064"</assert>
			<assert test="@codeSystemName!=''">У3-20.1.4: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-20.1.4: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-20.1.4: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-20.1.4: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']">
			<assert test="count(@nullFlavor)=0">У3-20.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='IND'">У3-20.1.5: Элемент participant обязан содержать один атрибут @typeCode со значением "IND"</assert>
			<assert test="count(participantRole)=1">У3-20.1.5.1: Элемент participant ОБЯЗАН содержать один [1..1] элемент participantRole</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole">
			<assert test="count(@nullFlavor)=0">У3-20.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode!=''">У3-20.1.5.1: Элемент participantRole обязан содержать один атрибут @classCode с не пустым значением</assert>
			<!-- Альтернатива У3-20.1.5.1 -->
			<assert test="@classCode=['MANU','SPEC']">У3-20.1.5.1: Элемент participantRole обязан содержать один атрибут @classCode с не пустым значением; допустимые значения: 'MANU','SPEC'</assert>
			<assert test="count(playingEntity)=1">У3-20.1.5.1.1: Элемент participantRole ОБЯЗАН содержать один [1..1] элемент playingEntity</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-20.1.5.1.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole[@classCode='SPEC']/playingEntity">
			<assert test="@classCode='MAT'">У3-20.1.5.1.1: Элемент playingEntity обязан содержать один атрибут @classCode с не пустым значением; Если атрибут participantRole/@classCode имеет значение 'SPEC', то атрибут @classCode должен иметь значение 'MAT'</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-20.1.5.1.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole[@classCode='MANU']/playingEntity">
			<assert test="@classCode='MMAT'">У3-20.1.5.1.1: Элемент playingEntity обязан содержать один атрибут @classCode с не пустым значением; Если атрибут participantRole/@classCode имеет значение 'MANU', то атрибут @classCode должен иметь значение 'MMAT'</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity">
			<assert test="count(@nullFlavor)=0">У3-20.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode!=''">У3-20.1.5.1.1: Элемент playingEntity обязан содержать один атрибут @classCode с не пустым значением</assert>
			<assert test="count(code)=1">У3-20.1.5.1.1.1: Элемент playingEntity ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(desc)=[0,1]">У3-20.1.5.1.1.2: Элемент playingEntity МОЖЕТ содержать не более одного [0..1] элемента desc</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity/code[not(@nullFlavor)]">
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1367','1.2.643.5.1.13.2.1.1.644']">У3-20.1.5.1.1.1: Элемент code должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1367"</assert>
			<assert test="@codeSystemName!=''">У3-20.1.5.1.1.1: Элемент code должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-20.1.5.1.1.1: Элемент code должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-20.1.5.1.1.1: Элемент code должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-20.1.5.1.1.1: Элемент code должен содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity/code[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
			<!-- Альтернатива У3-20.1.5.1.1.1 -->
			<assert test="@nullFlavor = 'OTH'">У3-20.1.5.1.1.1: Допустимые значения для атрибута  nullFlavor: 'OTH'</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-20.1.5.1.1.2 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity[code/@nullFlavor='OTH']">
			<assert test="count(desc)=1">У3-20.1.5.1.1.2: Элемент playingEntity МОЖЕТ содержать не более одного [0..1] элемента desc; Если атрибут playingEntity/code/@nullFlavor представлен со значением 'OTH', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity/desc">
			<assert test="count(@nullFlavor)=0">У3-20.1.5.1.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/participant[@typeCode='IND']/participantRole/playingEntity/desc не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-20.1.5.1.1.2: Элемент desc должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']">
			<assert test="count(@nullFlavor)=0">У3-20.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='MFST'">У3-20.1.6: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "MFST"</assert>
			<assert test="count(observation)=1">У3-20.1.6.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation">
			<assert test="count(@nullFlavor)=0">У3-20.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-20.1.6.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-20.1.6.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-20.1.6.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-20.1.6.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=1">У3-20.1.6.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-20.1.6.1.2 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation[value/@code='15']">
			<assert test="count(text)=1">У3-20.1.6.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text; Если атрибут value/@code представлен со значением '15', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-20.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12328'">У3-20.1.6.1.1: Элемент code обязан содержать один атрибут @code со значением "12328"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-20.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-20.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-20.1.6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-20.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-20.1.6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-20.1.6.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-20.1.6.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='ALL']/section/entry[observation/code/@code='11036']/observation/entryRelationship[observation/code/@code='12328']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-20.1.6.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1063','1.2.643.5.1.13.2.1.1.705']">У3-20.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1063"</assert>
			<assert test="@codeSystemName!=''">У3-20.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-20.1.6.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-20.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-20.1.6.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']">
			<assert test="count(@nullFlavor)=0">У2-5.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-5.1.6.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section">
			<assert test="count(@nullFlavor)=0">У2-5.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-5.1.6.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-5.1.6.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='7006'])=1">У3-21: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/code">
			<assert test="count(@nullFlavor)=0">У2-5.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='EPIDEM'">У2-5.1.6.1.1: Элемент code обязан содержать один атрибут @code со значением "EPIDEM"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-5.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-5.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-5.1.6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-5.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/title">
			<assert test="count(@nullFlavor)=0">У2-5.1.6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-5.1.6.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']">
			<assert test="count(@nullFlavor)=0">У3-21: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-21.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']/observation">
			<assert test="count(@nullFlavor)=0">У3-21.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-21.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-21.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-21.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-21.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-21.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7006'">У3-21.1.1: Элемент code обязан содержать один атрибут @code со значением "7006"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-21.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-21.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-21.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-21.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-21.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LANAM']/section/component[section/code/@code='EPIDEM']/section/entry[observation/code/@code='7006']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-21.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-21.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']">
			<assert test="count(@nullFlavor)=0">У2-6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-6.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section">
			<assert test="count(@nullFlavor)=0">У2-6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-6.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-6.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002'])>=1">У3-22: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/code">
			<assert test="count(@nullFlavor)=0">У2-6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='RESCONS'">У2-6.1.1: Элемент code обязан содержать один атрибут @code со значением "RESCONS"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/title">
			<assert test="count(@nullFlavor)=0">У2-6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-6.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']">
			<assert test="count(@nullFlavor)=0">У3-22: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-22.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation">
			<assert test="count(@nullFlavor)=0">У3-22.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-22.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-22.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-22.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-22.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-22.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-22.1.4: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
			<assert test="count(performer)=1">У3-22.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент performer</assert>
			<assert test="count(reference)=1">У3-22.1.6: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/code">
			<assert test="@nullFlavor='NI'">У3-22.1.1: Элемент code обязан содержать один атрибут @nullFlavor со значением "NI"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-22.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-22.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-22.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-22.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='ST'">У3-22.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-22.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='ST'">У3-22.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer">
			<assert test="count(@nullFlavor)=0">У3-22.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(assignedEntity)=1">У3-22.1.5.1: Элемент performer ОБЯЗАН содержать один [1..1] элемент assignedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[1])=1">У3-22.1.5.1.1: Элемент assignedEntity ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор медицинского работника в МИС)</assert>
			<assert test="count(code)=1">У3-22.1.5.1.2: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(telecom)=[0,1]">У3-22.1.5.1.3: Элемент assignedEntity МОЖЕТ содержать не более одного [0..1] элемента telecom</assert>
			<assert test="count(assignedPerson)=1">У3-22.1.5.1.4: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент assignedPerson</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-22.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У3-22.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У3-22.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/code">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1002','1.2.643.5.1.13.2.1.1.733']">У3-22.1.5.1.2: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1002"</assert>
			<assert test="@codeSystemName!=''">У3-22.1.5.1.2: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-22.1.5.1.2: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-22.1.5.1.2: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-22.1.5.1.2: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/telecom">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У3-22.1.5.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У3-22.1.5.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У3-22.1.5.1.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У3-22.1.5.1.4.1: Элемент assignedPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У3-22.1.5.1.4.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У3-22.1.5.1.4.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У3-22.1.5.1.4.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name/family">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-22.1.5.1.4.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name/given">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-22.1.5.1.4.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У3-22.1.5.1.4.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/performer/assignedEntity/assignedPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-22.1.5.1.4.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-22.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-22.1.6: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-22.1.6.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-22.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-22.1.6.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-22.1.6.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-22.1.6.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-22.1.6.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-22.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-22.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-22.1.6.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-22.1.6.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-22.1.6.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESCONS']/section/entry[observation/performer/assignedEntity/code/@codeSystem='1.2.643.5.1.13.13.11.1002']/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']">
			<assert test="count(@nullFlavor)=0">У2-7: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-7.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section">
			<assert test="count(@nullFlavor)=0">У2-7.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-7.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-7.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780'])>=1">У3-23: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/code">
			<assert test="count(@nullFlavor)=0">У2-7.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='CONSILIUMDECISION'">У2-7.1.1: Элемент code обязан содержать один атрибут @code со значением "CONSILIUMDECISION"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-7.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-7.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-7.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-7.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/title">
			<assert test="count(@nullFlavor)=0">У2-7.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-7.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']">
			<assert test="count(@nullFlavor)=0">У3-23: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-23.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation">
			<assert test="count(@nullFlavor)=0">У3-23.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-23.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-23.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-23.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-23.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-23.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-23.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='6026'])=1">У3-23.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент entryRelationship</assert>
			<assert test="count(reference)=1">У3-23.1.6: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-23.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.780'">У3-23.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.780"</assert>
			<assert test="@codeSystemName!=''">У3-23.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-23.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-23.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-23.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-23.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-23.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-23.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-23.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-23.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-23.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-23.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']">
			<assert test="count(@nullFlavor)=0">У3-23.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-23.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-23.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation">
			<assert test="count(@nullFlavor)=0">У3-23.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-23.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-23.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-23.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-23.1.5.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=1">У3-23.1.5.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-23.1.5.1.2 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation[value/@code='10']">
			<assert test="count(text)=1">У3-23.1.5.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text; Если атрибут value/@code представлен со значением '10', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-23.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='6026'">У3-23.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "6026"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-23.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-23.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-23.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-23.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-23.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-23.1.5.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-23.1.5.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/entryRelationship[observation/code/@code='6026']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-23.1.5.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1506'">У3-23.1.5.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1506"</assert>
			<assert test="@codeSystemName!=''">У3-23.1.5.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-23.1.5.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-23.1.5.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-23.1.5.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-23.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-23.1.6: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-23.1.6.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-23.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-23.1.6.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-23.1.6.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-23.1.6.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-23.1.6.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-23.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-23.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-23.1.6.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-23.1.6.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-23.1.6.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='CONSILIUMDECISION']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.780']/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']">
			<assert test="count(@nullFlavor)=0">У2-8: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-8.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section">
			<assert test="count(@nullFlavor)=0">У2-8.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-8.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-8.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/entryRelationship/observation/code/@code='12475'])>=1">У3-24: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/code">
			<assert test="count(@nullFlavor)=0">У2-8.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='COMMISSION'">У2-8.1.1: Элемент code обязан содержать один атрибут @code со значением "COMMISSION"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-8.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-8.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-8.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-8.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/title">
			<assert test="count(@nullFlavor)=0">У2-8.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-8.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']">
			<assert test="count(@nullFlavor)=0">У3-24: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-24.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation">
			<assert test="count(@nullFlavor)=0">У3-24.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-24.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-24.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-24.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-24.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-24.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-24.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='12475'])=1">У3-24.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент entryRelationship</assert>
			<assert test="count(reference)=1">У3-24.1.6: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/code[not(@nullFlavor)]">
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.941'">У3-24.1.1: Элемент code должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.941"</assert>
			<assert test="@codeSystemName!=''">У3-24.1.1: Элемент code должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-24.1.1: Элемент code должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-24.1.1: Элемент code должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-24.1.1: Элемент code должен содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="count(originalText)=[0,1]">У3-24.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента originalText</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/code[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
			<!-- Альтернатива У3-24.1.1 -->
			<assert test="@nullFlavor = ['NA', 'OTH']">У3-24.1.1: Допустимые значения для атрибута  nullFlavor: 'NA', 'OTH'</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-24.1.1.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/code[@nullFlavor='OTH']">
			<assert test="count(originalText)=1">У3-24.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента originalText; Если атрибут code/@nullFlavor представлен со значением 'OTH', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/code/originalText">
			<assert test="count(@nullFlavor)=0">У3-24.1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/code/originalText не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-24.1.1.1: Элемент originalText должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-24.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-24.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-24.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-24.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-24.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-24.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-24.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']">
			<assert test="count(@nullFlavor)=0">У3-24.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-24.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-24.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation">
			<assert test="count(@nullFlavor)=0">У3-24.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-24.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-24.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-24.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-24.1.5.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=1">У3-24.1.5.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-24.1.5.1.2 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation[value/@code='10']">
			<assert test="count(text)=1">У3-24.1.5.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text; Если атрибут value/@code представлен со значением '10', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-24.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12475'">У3-24.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "12475"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-24.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-24.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-24.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-24.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-24.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-24.1.5.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-24.1.5.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/entryRelationship[observation/code/@code='12475']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-24.1.5.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1506'">У3-24.1.5.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1506"</assert>
			<assert test="@codeSystemName!=''">У3-24.1.5.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-24.1.5.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-24.1.5.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-24.1.5.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-24.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-24.1.6: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-24.1.6.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-24.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-24.1.6.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-24.1.6.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-24.1.6.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-24.1.6.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-24.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-24.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-24.1.6.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-24.1.6.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-24.1.6.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='COMMISSION']/section/entry[observation/entryRelationship/observation/code/@code='12475']/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']">
			<assert test="count(@nullFlavor)=0">У2-9: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-9.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section">
			<assert test="count(@nullFlavor)=0">У2-9.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-9.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-9.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471'])>=1">У3-25: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/code">
			<assert test="count(@nullFlavor)=0">У2-9.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='RESINSTR'">У2-9.1.1: Элемент code обязан содержать один атрибут @code со значением "RESINSTR"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-9.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-9.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-9.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-9.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/title">
			<assert test="count(@nullFlavor)=0">У2-9.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-9.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']">
			<assert test="count(@nullFlavor)=0">У3-25: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-25.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation">
			<assert test="count(@nullFlavor)=0">У3-25.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-25.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-25.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-25.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-25.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-25.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-25.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(reference)=1">У3-25.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-25.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1471'">У3-25.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1471"</assert>
			<assert test="@codeSystemName!=''">У3-25.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-25.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@displayName!=''">У3-25.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-25.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-25.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-25.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-25.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-25.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-25.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-25.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-25.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-25.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-25.1.5: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-25.1.5.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-25.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-25.1.5.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-25.1.5.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-25.1.5.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-25.1.5.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-25.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-25.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-25.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-25.1.5.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-25.1.5.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESINSTR']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1471']/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']">
			<assert test="count(@nullFlavor)=0">У2-10: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-10.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section">
			<assert test="count(@nullFlavor)=0">У2-10.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-10.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-10.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry)>=1">У3-26: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/code">
			<assert test="count(@nullFlavor)=0">У2-10.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='RESLAB'">У2-10.1.1: Элемент code обязан содержать один атрибут @code со значением "RESLAB"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-10.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-10.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-10.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-10.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/title">
			<assert test="count(@nullFlavor)=0">У2-10.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-10.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry">
			<assert test="count(@nullFlavor)=0">У3-26: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-26.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation">
			<assert test="count(@nullFlavor)=0">У3-26.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-26.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-26.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-26.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-26.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-26.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=[0,1]">У3-26.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента value</assert>
			<assert test="count(entryRelationship[observation/code/@code='7028'])>=0">У3-26.1.5: Элемент observation МОЖЕТ содержать произвольное количество [0..*] элементов entryRelationship</assert>
			<assert test="count(reference)=1">У3-26.1.6: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/code[not(@nullFlavor)]">
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1437','1.2.643.5.1.13.13.11.10043']">У3-26.1.1: Элемент code должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1437"</assert>
			<assert test="@codeSystemName!=''">У3-26.1.1: Элемент code должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-26.1.1: Элемент code должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-26.1.1: Элемент code должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-26.1.1: Элемент code должен содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="count(originalText)=[0,1]">У3-26.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента originalText</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/code[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
			<!-- Альтернатива У3-26.1.1 -->
			<assert test="@nullFlavor = 'OTH'">У3-26.1.1: Допустимые значения для атрибута  nullFlavor: 'OTH'</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-26.1.1.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/code[@nullFlavor='OTH']">
			<assert test="count(originalText)=1">У3-26.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента originalText; Если атрибут code/@nullFlavor представлен со значением 'OTH', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/code/originalText">
			<assert test="count(@nullFlavor)=0">У3-26.1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/code/originalText не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-26.1.1.1: Элемент originalText должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/text">
			<assert test="count(@nullFlavor)=0">У3-26.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-26.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-26.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-26.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/value">
			<assert test="count(@nullFlavor)=0">У3-26.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-26.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-26.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']">
			<assert test="count(@nullFlavor)=0">У3-26.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-26.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-26.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-26.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-26.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-26.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=1">У3-26.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент text</assert>
			<assert test="count(value)=1">У3-26.1.5.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='8102'])=[0,1]">У3-26.1.5.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7028'">У3-26.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "7028"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-26.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-26.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-26.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-26.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-26.1.5.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-26.1.5.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-26.1.5.1.3: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-26.1.5.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-26.1.5.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-26.1.5.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-26.1.5.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-26.1.5.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-26.1.5.1.4.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=[0,1]">У3-26.1.5.1.4.1.3: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента value</assert>
			<assert test="count(referenceRange)=[0,1]">У3-26.1.5.1.4.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента referenceRange</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8102'">У3-26.1.5.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "8102"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-26.1.5.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-26.1.5.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-26.1.5.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-26.1.5.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-26.1.5.1.4.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-26.1.5.1.4.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-26.1.5.1.4.1.3: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/referenceRange">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/referenceRange не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observationRange)=1">У3-26.1.5.1.4.1.4.1: Элемент referenceRange ОБЯЗАН содержать один [1..1] элемент observationRange</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/referenceRange/observationRange">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/referenceRange/observationRange не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(text)=1">У3-26.1.5.1.4.1.4.1.1: Элемент observationRange ОБЯЗАН содержать один [1..1] элемент text</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/referenceRange/observationRange/text">
			<assert test="count(@nullFlavor)=0">У3-26.1.5.1.4.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/entryRelationship[observation/code/@code='7028']/observation/entryRelationship[observation/code/@code='8102']/observation/referenceRange/observationRange/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-26.1.5.1.4.1.4.1.1: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-26.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-26.1.6: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-26.1.6.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-26.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-26.1.6.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-26.1.6.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-26.1.6.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-26.1.6.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-26.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-26.1.6.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-26.1.6.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-26.1.6.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-26.1.6.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='RESLAB']/section/entry/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']">
			<assert test="count(@nullFlavor)=0">У2-11: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-11.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section">
			<assert test="count(@nullFlavor)=0">У2-11.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-11.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-11.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@nullFlavor='NI'])>=1">У3-27: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/code">
			<assert test="count(@nullFlavor)=0">У2-11.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='GISTRESULT'">У2-11.1.1: Элемент code обязан содержать один атрибут @code со значением "GISTRESULT"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-11.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-11.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-11.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-11.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/title">
			<assert test="count(@nullFlavor)=0">У2-11.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-11.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']">
			<assert test="count(@nullFlavor)=0">У3-27: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-27.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation">
			<assert test="count(@nullFlavor)=0">У3-27.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-27.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-27.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-27.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-27.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-27.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-27.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(reference)=1">У3-27.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/code">
			<assert test="@nullFlavor='NI'">У3-27.1.1: Элемент code обязан содержать один атрибут @nullFlavor со значением "NI"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-27.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-27.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-27.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-27.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-27.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-27.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-27.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-27.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-27.1.5: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-27.1.5.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-27.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-27.1.5.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-27.1.5.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-27.1.5.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-27.1.5.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-27.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-27.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-27.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-27.1.5.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-27.1.5.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='GISTRESULT']/section/entry[observation/code/@nullFlavor='NI']/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']">
			<assert test="count(@nullFlavor)=0">У2-12: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-12.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section">
			<assert test="count(@nullFlavor)=0">У2-12.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-12.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-12.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry)>=1">У3-28: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/code">
			<assert test="count(@nullFlavor)=0">У2-12.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='SUR'">У2-12.1.1: Элемент code обязан содержать один атрибут @code со значением "SUR"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-12.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-12.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-12.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-12.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/title">
			<assert test="count(@nullFlavor)=0">У2-12.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-12.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry">
			<assert test="count(@nullFlavor)=0">У3-28: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-28.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation">
			<assert test="count(@nullFlavor)=0">У3-28.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-28.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-28.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-28.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-28.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-28.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-28.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(reference)=1">У3-28.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/code[not(@nullFlavor)]">
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1070','1.2.643.5.1.13.2.1.1.473']">У3-28.1.1: Элемент code должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1070"</assert>
			<assert test="@codeSystemName!=''">У3-28.1.1: Элемент code должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-28.1.1: Элемент code должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-28.1.1: Элемент code должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-28.1.1: Элемент code должен содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="count(originalText)=1">У3-28.1.1.1: Элемент code ОБЯЗАН содержать один [1..1] элемент originalText</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/code[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
			<!-- Альтернатива У3-28.1.1 -->
			<assert test="@nullFlavor = 'OTH'">У3-28.1.1: Допустимые значения для атрибута  nullFlavor: 'OTH'</assert>
			<!-- Альтернатива У3-28.1.1.1 -->
			<assert test="count(originalText)=1">У3-28.1.1.1: Элемент code ОБЯЗАН содержать один [1..1] элемент originalText</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/code/originalText">
			<assert test="count(@nullFlavor)=0">У3-28.1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/code/originalText не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-28.1.1.1: Элемент originalText должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/text">
			<assert test="count(@nullFlavor)=0">У3-28.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-28.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-28.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=1">У3-28.1.3.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=1">У3-28.1.3.2: Элемент effectiveTime ДОЛЖЕН содержать один [1..1] элемент high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У3-28.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-28.1.3.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/effectiveTime/high[not(@nullFlavor)]">
			<assert test="@value!=''">У3-28.1.3.2: Элемент high должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/effectiveTime/high[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/value">
			<assert test="count(@nullFlavor)=0">У3-28.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-28.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-28.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-28.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-28.1.5: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-28.1.5.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-28.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-28.1.5.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-28.1.5.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-28.1.5.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-28.1.5.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-28.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-28.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-28.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-28.1.5.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-28.1.5.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SUR']/section/entry/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']">
			<assert test="count(@nullFlavor)=0">У2-13: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-13.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section">
			<assert test="count(@nullFlavor)=0">У2-13.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-13.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-13.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386'])>=1">У3-29: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/code">
			<assert test="count(@nullFlavor)=0">У2-13.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='TRANSFUSINFO'">У2-13.1.1: Элемент code обязан содержать один атрибут @code со значением "TRANSFUSINFO"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-13.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-13.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-13.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-13.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/title">
			<assert test="count(@nullFlavor)=0">У2-13.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-13.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']">
			<assert test="count(@nullFlavor)=0">У3-29: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-29.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation">
			<assert test="count(@nullFlavor)=0">У3-29.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-29.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-29.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-29.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-29.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-29.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-29.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(reference)=1">У3-29.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-29.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1386'">У3-29.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1386"</assert>
			<assert test="@codeSystemName!=''">У3-29.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-29.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-29.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-29.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-29.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-29.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-29.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=1">У3-29.1.3.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=1">У3-29.1.3.2: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У3-29.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-29.1.3.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/effectiveTime/high">
			<assert test="count(@nullFlavor)=0">У3-29.1.3.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/effectiveTime/high не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-29.1.3.2: Элемент high обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-29.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-29.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-29.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-29.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-29.1.5: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-29.1.5.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-29.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-29.1.5.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-29.1.5.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-29.1.5.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-29.1.5.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-29.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-29.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-29.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-29.1.5.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-29.1.5.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='TRANSFUSINFO']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1386']/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']">
			<assert test="count(@nullFlavor)=0">У2-14: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-14.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section">
			<assert test="count(@nullFlavor)=0">У2-14.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-14.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-14.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry)>=1">У3-30: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/code">
			<assert test="count(@nullFlavor)=0">У2-14.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='ELSEPROCEDURE'">У2-14.1.1: Элемент code обязан содержать один атрибут @code со значением "ELSEPROCEDURE"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-14.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-14.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-14.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-14.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/title">
			<assert test="count(@nullFlavor)=0">У2-14.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-14.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry">
			<assert test="count(@nullFlavor)=0">У3-30: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-30.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation">
			<assert test="count(@nullFlavor)=0">У3-30.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-30.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-30.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-30.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-30.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-30.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=[0,1]">У3-30.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента value</assert>
			<assert test="count(reference)=1">У3-30.1.5: Элемент observation ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/code[not(@nullFlavor)]">
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.785'">У3-30.1.1: Элемент code должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.785"</assert>
			<assert test="@codeSystemName!=''">У3-30.1.1: Элемент code должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-30.1.1: Элемент code должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-30.1.1: Элемент code должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-30.1.1: Элемент code должен содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="count(originalText)=[0,1]">У3-30.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента originalText</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/code[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
			<!-- Альтернатива У3-30.1.1 -->
			<assert test="@nullFlavor = 'OTH'">У3-30.1.1: Допустимые значения для атрибута  nullFlavor: 'OTH'</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-30.1.1.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/code[@nullFlavor='OTH']">
			<assert test="count(originalText)=1">У3-30.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента originalText; Если атрибут code/@nullFlavor представлен со значением 'OTH', то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/code/originalText">
			<assert test="count(@nullFlavor)=0">У3-30.1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/code/originalText не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-30.1.1.1: Элемент originalText должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/text">
			<assert test="count(@nullFlavor)=0">У3-30.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-30.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-30.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=[0,1]">У3-30.1.3.1: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента low</assert>
			<assert test="count(high)=[0,1]">У3-30.1.3.2: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента high</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-30.1.3.1, У3-30.1.3.2 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime[not(@value)]">
			<assert test="count(low)=1">У3-30.1.3.1: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента low; Если медицинская процедура или манипуляция выполнялась некоторый интервал времени, то элемент обязан быть представлен</assert>
			<assert test="count(high)=1">У3-30.1.3.2: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента high; Если медицинская процедура или манипуляция выполнялась некоторый интервал времени, то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У3-30.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-30.1.3.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime/high">
			<assert test="count(@nullFlavor)=0">У3-30.1.3.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/effectiveTime/high не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-30.1.3.2: Элемент high обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/value">
			<assert test="count(@nullFlavor)=0">У3-30.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-30.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-30.1.4: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference">
			<assert test="count(@nullFlavor)=0">У3-30.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-30.1.5: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-30.1.5.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-30.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-30.1.5.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-30.1.5.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-30.1.5.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-30.1.5.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-30.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-30.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-30.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-30.1.5.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-30.1.5.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='ELSEPROCEDURE']/section/entry/observation/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']">
			<assert test="count(@nullFlavor)=0">У2-15: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-15.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section">
			<assert test="count(@nullFlavor)=0">У2-15.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-15.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-15.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT'])>=1">У3-31: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/code">
			<assert test="count(@nullFlavor)=0">У2-15.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='DRUG'">У2-15.1.1: Элемент code обязан содержать один атрибут @code со значением "DRUG"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-15.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-15.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-15.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-15.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/title">
			<assert test="count(@nullFlavor)=0">У2-15.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-15.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']">
			<assert test="count(@nullFlavor)=0">У3-31: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(substanceAdministration)=1">У3-31.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент substanceAdministration</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration">
			<assert test="count(@nullFlavor)=0">У3-31.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='SBADM'">У3-31.1: Элемент substanceAdministration обязан содержать один атрибут @classCode со значением "SBADM"</assert>
			<assert test="@moodCode='EVN'">У3-31.1: Элемент substanceAdministration обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-31.1.1: Элемент substanceAdministration ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-31.1.2: Элемент substanceAdministration МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime[1])=1">У3-31.1.3: Элемент substanceAdministration ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(effectiveTime[2])=1">У3-31.1.4: Элемент substanceAdministration ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(routeCode)=1">У3-31.1.5: Элемент substanceAdministration ОБЯЗАН содержать один [1..1] элемент routeCode</assert>
			<assert test="count(doseQuantity)=1">У3-31.1.6: Элемент substanceAdministration ОБЯЗАН содержать один [1..1] элемент doseQuantity</assert>
			<assert test="count(administrationUnitCode)=[0,1]">У3-31.1.7: Элемент substanceAdministration МОЖЕТ содержать не более одного [0..1] элемента administrationUnitCode</assert>
			<assert test="count(consumable)=1">У3-31.1.8: Элемент substanceAdministration ОБЯЗАН содержать один [1..1] элемент consumable</assert>
			<assert test="count(precondition)=[0,1]">У3-31.1.9: Элемент substanceAdministration МОЖЕТ содержать не более одного [0..1] элемента precondition</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/code">
			<assert test="@nullFlavor='NI'">У3-31.1.1: Элемент code обязан содержать один атрибут @nullFlavor со значением "NI"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/text">
			<assert test="count(@nullFlavor)=0">У3-31.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-31.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[1][not(@nullFlavor)]">
			<assert test="@xsi:type='IVL_TS'">У3-31.1.3: Элемент effectiveTime обязан содержать один атрибут @xsi:type со значением "IVL_TS"</assert>
			<assert test="count(width)=[0,1]">У3-31.1.3.1: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента width</assert>
			<assert test="count(low)=[0,1]">У3-31.1.3.2: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента low</assert>
			<assert test="count(high)=[0,1]">У3-31.1.3.3: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента high</assert>
			<!-- Альтернатива У3-31.1.3, У3-31.1.3.1, У3-31.1.3.2, У3-31.1.3.3 -->
			<assert test="if (count(width)=1) then count(low)=0 and count(high)=0 else count(low)=1 and count(high)=1">У3-31.1.3: Элемент effectiveTime, при отсутствии атрибута @nullFlavor, обязан ИЛИ содержать элемент effectiveTime/width, ИЛИ содержать элементы effectiveTime/low и effectiveTime/high; Элемент effectiveTime/width не может быть представлен совместно с элементами effectiveTime/low и effectiveTime/high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[1][@nullFlavor]">
			<assert test="@xsi:type='IVL_TS'">У3-31.1.3: Элемент effectiveTime обязан содержать один атрибут @xsi:type со значением "IVL_TS"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[1]/width">
			<assert test="count(@nullFlavor)=0">У3-31.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime/width не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-31.1.3.1: Элемент width обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@unit!=''">У3-31.1.3.1: Элемент width обязан содержать один атрибут @unit с не пустым значением</assert>
			<assert test="count(translation)=1">У3-31.1.3.1.1: Элемент width ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[1]/width/translation">
			<assert test="count(@nullFlavor)=0">У3-31.1.3.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime/width/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-31.1.3.1.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.3.1.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-31.1.3.1.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.3.1.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.3.1.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.3.1.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[1]/low">
			<assert test="count(@nullFlavor)=0">У3-31.1.3.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-31.1.3.2: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[1]/high">
			<assert test="count(@nullFlavor)=0">У3-31.1.3.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime/high не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-31.1.3.3: Элемент high обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[2][not(@nullFlavor)]">
			<assert test="@xsi:type='PIVL_TS'">У3-31.1.4: Элемент effectiveTime обязан содержать один атрибут @xsi:type со значением "PIVL_TS"</assert>
			<assert test="@institutionSpecified!=''">У3-31.1.4: Элемент effectiveTime должен содержать один атрибут @institutionSpecified с не пустым значением</assert>
			<!-- Альтернатива У3-31.1.4 -->
			<assert test="@institutionSpecified=['true','false']">У3-31.1.4: Элемент effectiveTime должен содержать один атрибут @institutionSpecified с не пустым значением; допустимые значения: 'true','false'</assert>
			<assert test="count(period)=1">У3-31.1.4.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент period</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[2][@nullFlavor]">
			<assert test="@xsi:type='PIVL_TS'">У3-31.1.4: Элемент effectiveTime обязан содержать один атрибут @xsi:type со значением "PIVL_TS"</assert>
			<assert test="count(@institutionSpecified)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @institutionSpecified</assert>
			<!-- Альтернатива У3-31.1.4 -->
			<assert test="@nullFlavor = 'NA'">У3-31.1.4: Допустимые значения для атрибута  nullFlavor: 'NA'</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[2]/period">
			<assert test="count(@nullFlavor)=0">У3-31.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime/period не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-31.1.4.1: Элемент period обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@unit!=''">У3-31.1.4.1: Элемент period обязан содержать один атрибут @unit с не пустым значением</assert>
			<assert test="count(translation)=1">У3-31.1.4.1.1: Элемент period ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime[2]/period/translation">
			<assert test="count(@nullFlavor)=0">У3-31.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/effectiveTime/period/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-31.1.4.1.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.4.1.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-31.1.4.1.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.4.1.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.4.1.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.4.1.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/routeCode">
			<assert test="count(@nullFlavor)=0">У3-31.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/routeCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1468'">У3-31.1.5: Элемент routeCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1468"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.5: Элемент routeCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.5: Элемент routeCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.5: Элемент routeCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.5: Элемент routeCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/doseQuantity">
			<assert test="count(@nullFlavor)=0">У3-31.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/doseQuantity не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-31.1.6: Элемент doseQuantity обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@unit!=''">У3-31.1.6: Элемент doseQuantity обязан содержать один атрибут @unit с не пустым значением</assert>
			<assert test="count(translation)=1">У3-31.1.6.1: Элемент doseQuantity ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/doseQuantity/translation">
			<assert test="count(@nullFlavor)=0">У3-31.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/doseQuantity/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-31.1.6.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.6.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-31.1.6.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.6.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.6.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.6.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-31.1.7 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration[consumable/manufacturedProduct/manufacturedMaterial/code/@nullFlavor]">
			<assert test="count(administrationUnitCode)=1">У3-31.1.7: Элемент substanceAdministration МОЖЕТ содержать не более одного [0..1] элемента administrationUnitCode; Если атрибут consumable/manufacturedProduct/manufacturedMaterial/code/@nullFlavor представлен, то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/administrationUnitCode">
			<assert test="count(@nullFlavor)=0">У3-31.1.7: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/administrationUnitCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1466'">У3-31.1.7: Элемент administrationUnitCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1466"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.7: Элемент administrationUnitCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.7: Элемент administrationUnitCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.7: Элемент administrationUnitCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.7: Элемент administrationUnitCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable">
			<assert test="count(@nullFlavor)=0">У3-31.1.8: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='CSM'">У3-31.1.8: Элемент consumable обязан содержать один атрибут @typeCode со значением "CSM"</assert>
			<assert test="count(manufacturedProduct)=1">У3-31.1.8.1: Элемент consumable ОБЯЗАН содержать один [1..1] элемент manufacturedProduct</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct">
			<assert test="count(@nullFlavor)=0">У3-31.1.8.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='MANU'">У3-31.1.8.1: Элемент manufacturedProduct обязан содержать один атрибут @classCode со значением "MANU"</assert>
			<assert test="count(manufacturedMaterial)=1">У3-31.1.8.1.1: Элемент manufacturedProduct ОБЯЗАН содержать один [1..1] элемент manufacturedMaterial</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial">
			<assert test="count(@nullFlavor)=0">У3-31.1.8.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='MMAT'">У3-31.1.8.1.1: Элемент manufacturedMaterial обязан содержать один атрибут @classCode со значением "MMAT"</assert>
			<assert test="@determinerCode='KIND'">У3-31.1.8.1.1: Элемент manufacturedMaterial обязан содержать один атрибут @determinerCode со значением "KIND"</assert>
			<assert test="count(code)=1">У3-31.1.8.1.1.1: Элемент manufacturedMaterial ДОЛЖЕН содержать один [1..1] элемент code</assert>
			<assert test="count(name)=[0,1]">У3-31.1.8.1.1.2: Элемент manufacturedMaterial МОЖЕТ содержать не более одного [0..1] элемента name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/code[not(@nullFlavor)]">
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.611'">У3-31.1.8.1.1.1: Элемент code должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.611"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.8.1.1.1: Элемент code должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.8.1.1.1: Элемент code должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.8.1.1.1: Элемент code должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.8.1.1.1: Элемент code должен содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="count(translation)=[0,1]">У3-31.1.8.1.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/code[@nullFlavor]">
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-31.1.8.1.1.1.1 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial[not(name) and code[@nullFlavor]]">
			<assert test="count(code/translation)=1">У3-31.1.8.1.1.1.1: Элемент code МОЖЕТ содержать не более одного [0..1] элемента translation; Если элемент name не представлен и атрибут code/@nullFlavor представлен, то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/code/translation">
			<assert test="count(@nullFlavor)=0">У3-31.1.8.1.1.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/code/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1367','1.2.643.5.1.13.2.1.1.644']">У3-31.1.8.1.1.1.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1367"</assert>
			<assert test="@codeSystemName!=''">У3-31.1.8.1.1.1.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-31.1.8.1.1.1.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-31.1.8.1.1.1.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-31.1.8.1.1.1.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/name">
			<assert test="count(@nullFlavor)=0">У3-31.1.8.1.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/name не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-31.1.8.1.1.2: Элемент name должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition">
			<assert test="count(@nullFlavor)=0">У3-31.1.9: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='PRCN'">У3-31.1.9: Элемент precondition обязан содержать один атрибут @typeCode со значением "PRCN"</assert>
			<assert test="count(criterion)=1">У3-31.1.9.1: Элемент precondition ОБЯЗАН содержать один [1..1] элемент criterion</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition/criterion">
			<assert test="count(@nullFlavor)=0">У3-31.1.9.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition/criterion не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У3-31.1.9.1.1: Элемент criterion ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-31.1.9.1.2: Элемент criterion ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition/criterion/code">
			<assert test="count(@nullFlavor)=0">У3-31.1.9.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition/criterion/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='ASSERTION'">У3-31.1.9.1.1: Элемент code обязан содержать один атрибут @code со значением "ASSERTION"</assert>
			<assert test="@codeSystem='2.16.840.1.113883.5.4'">У3-31.1.9.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "2.16.840.1.113883.5.4"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition/criterion/value">
			<assert test="count(@nullFlavor)=0">У3-31.1.9.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DRUG']/section/entry[substanceAdministration/consumable/manufacturedProduct/manufacturedMaterial/@classCode='MMAT']/substanceAdministration/precondition/criterion/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-31.1.9.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-31.1.9.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']">
			<assert test="count(@nullFlavor)=0">У2-16: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-16.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section">
			<assert test="count(@nullFlavor)=0">У2-16.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-16.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-16.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262'])>=1">У3-32: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/code">
			<assert test="count(@nullFlavor)=0">У2-16.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='VITALPARAM'">У2-16.1.1: Элемент code обязан содержать один атрибут @code со значением "VITALPARAM"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-16.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-16.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-16.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-16.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/title">
			<assert test="count(@nullFlavor)=0">У2-16.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-16.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']">
			<assert test="count(@nullFlavor)=0">У3-32: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262'])=1">У3-32.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент organizer</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']">
			<assert test="count(@nullFlavor)=0">У3-32.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='CLUSTER'">У3-32.1: Элемент organizer обязан содержать один атрибут @classCode со значением "CLUSTER"</assert>
			<assert test="@moodCode='EVN'">У3-32.1: Элемент organizer обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(statusCode)=1">У3-32.1.1: Элемент organizer ОБЯЗАН содержать один [1..1] элемент statusCode</assert>
			<assert test="count(effectiveTime)=1">У3-32.1.2: Элемент organizer ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(precondition)=[0,1]">У3-32.1.3: Элемент organizer МОЖЕТ содержать не более одного [0..1] элемента precondition</assert>
			<assert test="count(component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262'])=[1,2]">У3-32.1.4: Элемент organizer ОБЯЗАН содержать от одного до двух [1..2] элементов component</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/statusCode">
			<assert test="count(@nullFlavor)=0">У3-32.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/statusCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='completed'">У3-32.1.1: Элемент statusCode обязан содержать один атрибут @code со значением "completed"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-32.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-32.1.2: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition">
			<assert test="count(@nullFlavor)=0">У3-32.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='PRCN'">У3-32.1.3: Элемент precondition обязан содержать один атрибут @typeCode со значением "PRCN"</assert>
			<assert test="count(criterion)=1">У3-32.1.3.1: Элемент precondition ОБЯЗАН содержать один [1..1] элемент criterion</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition/criterion">
			<assert test="count(@nullFlavor)=0">У3-32.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition/criterion не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У3-32.1.3.1.1: Элемент criterion ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-32.1.3.1.2: Элемент criterion ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition/criterion/code">
			<assert test="count(@nullFlavor)=0">У3-32.1.3.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition/criterion/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='ASSERTION'">У3-32.1.3.1.1: Элемент code обязан содержать один атрибут @code со значением "ASSERTION"</assert>
			<assert test="@codeSystem='2.16.840.1.113883.5.4'">У3-32.1.3.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "2.16.840.1.113883.5.4"</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition/criterion/value">
			<assert test="count(@nullFlavor)=0">У3-32.1.3.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/precondition/criterion/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-32.1.3.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-32.1.3.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']">
			<assert test="count(@nullFlavor)=0">У3-32.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-32.1.4: Элемент component обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-32.1.4.1: Элемент component ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-32.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-32.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-32.1.4.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор параметра внутри документа)</assert>
			<assert test="count(code)=1">У3-32.1.4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-32.1.4.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='6034'])=[0,1]">У3-32.1.4.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='8034'])=[0,1]">У3-32.1.4.1.5: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(referenceRange)=[0,1]">У3-32.1.4.1.6: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента referenceRange</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-32.1.4.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.52</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.52$')">У3-32.1.4.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.52</assert>
			<assert test="@extension!=''">У3-32.1.4.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.262','1.2.643.5.1.13.13.11.1010']">У3-32.1.4.1.2: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.262"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.2: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-32.1.4.1.2: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.2: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.2: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type!=''">У3-32.1.4.1.3: Элемент value обязан содержать один атрибут @xsi:type с не пустым значением</assert>
			<assert test="count(translation)=[0,1]">У3-32.1.4.1.3.1: Элемент value МОЖЕТ содержать не более одного [0..1] элемента translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/value/translation">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/value/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-32.1.4.1.3.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.3.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-32.1.4.1.3.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-32.1.4.1.3.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.3.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.3.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-32.1.4.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-32.1.4.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']/observation">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-32.1.4.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-32.1.4.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-32.1.4.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-32.1.4.1.4.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='6034'">У3-32.1.4.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "6034"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-32.1.4.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='CD'">У3-32.1.4.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.778'">У3-32.1.4.1.4.1.2: Элемент value должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.778"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.4.1.2: Элемент value должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-32.1.4.1.4.1.2: Элемент value должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.4.1.2: Элемент value должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.4.1.2: Элемент value должен содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='6034']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='CD'">У3-32.1.4.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-32.1.4.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-32.1.4.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']/observation">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-32.1.4.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-32.1.4.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-32.1.4.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-32.1.4.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8034'">У3-32.1.4.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "8034"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-32.1.4.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/entryRelationship[observation/code/@code='8034']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='INT'">У3-32.1.4.1.5.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "INT"</assert>
			<assert test="@value!=''">У3-32.1.4.1.5.1.2: Элемент value обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observationRange)=1">У3-32.1.4.1.6.1: Элемент referenceRange ОБЯЗАН содержать один [1..1] элемент observationRange</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(text)=1">У3-32.1.4.1.6.1.1: Элемент observationRange ОБЯЗАН содержать один [1..1] элемент text</assert>
			<assert test="count(value)=1">У3-32.1.4.1.6.1.2: Элемент observationRange ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/text">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-32.1.4.1.6.1.1: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='IVL_PQ'">У3-32.1.4.1.6.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "IVL_PQ"</assert>
			<assert test="count(low)=1">У3-32.1.4.1.6.1.2.1: Элемент value ДОЛЖЕН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=1">У3-32.1.4.1.6.1.2.2: Элемент value ДОЛЖЕН содержать один [1..1] элемент high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/low[not(@nullFlavor)]">
			<assert test="@value!=''">У3-32.1.4.1.6.1.2.1: Элемент low должен содержать один атрибут @value с не пустым значением</assert>
			<assert test="@unit!=''">У3-32.1.4.1.6.1.2.1: Элемент low должен содержать один атрибут @unit с не пустым значением</assert>
			<assert test="count(translation)=1">У3-32.1.4.1.6.1.2.1.1: Элемент low ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/low[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
			<assert test="count(@unit)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @unit</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/low/translation">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.6.1.2.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/low/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-32.1.4.1.6.1.2.1.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.6.1.2.1.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-32.1.4.1.6.1.2.1.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-32.1.4.1.6.1.2.1.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.6.1.2.1.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.6.1.2.1.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/high[not(@nullFlavor)]">
			<assert test="@value!=''">У3-32.1.4.1.6.1.2.2: Элемент high должен содержать один атрибут @value с не пустым значением</assert>
			<assert test="@unit!=''">У3-32.1.4.1.6.1.2.2: Элемент high должен содержать один атрибут @unit с не пустым значением</assert>
			<assert test="count(translation)=1">У3-32.1.4.1.6.1.2.2.1: Элемент high ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/high[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
			<assert test="count(@unit)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @unit</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/high/translation">
			<assert test="count(@nullFlavor)=0">У3-32.1.4.1.6.1.2.2.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='VITALPARAM']/section/entry[organizer/component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/organizer[component/observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/component[observation/code/@codeSystem='1.2.643.5.1.13.13.99.2.262']/observation/referenceRange/observationRange/value/high/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-32.1.4.1.6.1.2.2.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-32.1.4.1.6.1.2.2.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-32.1.4.1.6.1.2.2.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-32.1.4.1.6.1.2.2.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@displayName!=''">У3-32.1.4.1.6.1.2.2.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-32.1.4.1.6.1.2.2.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']">
			<assert test="count(@nullFlavor)=0">У2-17: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-17.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section">
			<assert test="count(@nullFlavor)=0">У2-17.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-17.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-17.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514'])>=1">У3-33: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/code">
			<assert test="count(@nullFlavor)=0">У2-17.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='SCORES'">У2-17.1.1: Элемент code обязан содержать один атрибут @code со значением "SCORES"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-17.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-17.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-17.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-17.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/title">
			<assert test="count(@nullFlavor)=0">У2-17.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-17.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']">
			<assert test="count(@nullFlavor)=0">У3-33: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-33.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation">
			<assert test="count(@nullFlavor)=0">У3-33.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-33.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-33.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-33.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=[0,1]">У3-33.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента effectiveTime</assert>
			<assert test="count(value)=[0,1]">У3-33.1.3: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента value</assert>
			<assert test="count(performer)=[0,1]">У3-33.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента performer</assert>
			<assert test="count(entryRelationship[observation/code/@code='8020'])>=0">У3-33.1.5: Элемент observation МОЖЕТ содержать произвольное количество [0..*] элементов entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='8019'])=[0,1]">У3-33.1.6: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-33.1.3 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation[not(entryRelationship[observation/code/@code='8020'])][not(entryRelationship[observation/code/@code='8019'])]">
			<assert test="count(value)=1">У3-33.1.3: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента value; Если элементы entryRelationship[observation/code/@code='8019'] и entryRelationship[observation/code/@code='8019'] отсутствуют, то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-33.1.5 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation[not(entryRelationship[observation/code/@code='8019'])][not(value)]">
			<assert test="count(entryRelationship[observation/code/@code='8020'])>=1">У3-33.1.5: Элемент observation МОЖЕТ содержать произвольное количество [0..*] элементов entryRelationship; Если элементы value и entryRelationship[observation/code/@code='8019'] отсутствуют, то хотя бы один элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<!-- Альтернатива У3-33.1.6 -->
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation[not(value)][not(entryRelationship[observation/code/@code='8020'])]">
			<assert test="count(entryRelationship[observation/code/@code='8019'])=1">У3-33.1.6: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship; Если элементы value и entryRelationship[observation/code/@code='8020'] отсутствуют, то элемент обязан быть представлен</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-33.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.11.1514'">У3-33.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1514"</assert>
			<assert test="@codeSystemName!=''">У3-33.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-33.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-33.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-33.1.2: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-33.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='PQ'">У3-33.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "PQ"</assert>
			<assert test="@value!=''">У3-33.1.3: Элемент value обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@unit!=''">У3-33.1.3: Элемент value обязан содержать один атрибут @unit с не пустым значением</assert>
			<assert test="count(translation)=1">У3-33.1.3.1: Элемент value ОБЯЗАН содержать один [1..1] элемент translation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/value/translation">
			<assert test="count(@nullFlavor)=0">У3-33.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/value/translation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1358','1.2.643.5.1.13.13.11.1031']">У3-33.1.3.1: Элемент translation обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1358"</assert>
			<assert test="@codeSystemName!=''">У3-33.1.3.1: Элемент translation обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@value!=''">У3-33.1.3.1: Элемент translation обязан содержать один атрибут @value с не пустым значением</assert>
			<assert test="@code!=''">У3-33.1.3.1: Элемент translation обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.3.1: Элемент translation обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.3.1: Элемент translation обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer">
			<assert test="count(@nullFlavor)=0">У3-33.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(assignedEntity)=1">У3-33.1.4.1: Элемент performer ОБЯЗАН содержать один [1..1] элемент assignedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[1])=1">У3-33.1.4.1.1: Элемент assignedEntity ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор медицинского работника в МИС)</assert>
			<assert test="count(code)=1">У3-33.1.4.1.2: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(telecom)=[0,1]">У3-33.1.4.1.3: Элемент assignedEntity МОЖЕТ содержать не более одного [0..1] элемента telecom</assert>
			<assert test="count(assignedPerson)=1">У3-33.1.4.1.4: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент assignedPerson</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-33.1.4.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У3-33.1.4.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У3-33.1.4.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/code">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1002','1.2.643.5.1.13.2.1.1.733']">У3-33.1.4.1.2: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1002"</assert>
			<assert test="@codeSystemName!=''">У3-33.1.4.1.2: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-33.1.4.1.2: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.4.1.2: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.4.1.2: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/telecom">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/telecom не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(@use!='')=[0,1]">У3-33.1.4.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="if (@use) then @use!='' else(not(@use))">У3-33.1.4.1.3: Элемент telecom должен содержать один атрибут @use с не пустым значением</assert>
			<assert test="@value!=''">У3-33.1.4.1.3: Элемент telecom обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(name)=1">У3-33.1.4.1.4.1: Элемент assignedPerson ОБЯЗАН содержать один [1..1] элемент name</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(family)=1">У3-33.1.4.1.4.1.1: Элемент name ОБЯЗАН содержать один [1..1] элемент family</assert>
			<assert test="count(given)=1">У3-33.1.4.1.4.1.2: Элемент name ОБЯЗАН содержать один [1..1] элемент given</assert>
			<assert test="count(identity:Patronymic)=[0,1]">У3-33.1.4.1.4.1.3: Элемент name МОЖЕТ содержать не более одного [0..1] элемента identity:Patronymic</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name/family">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name/family не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-33.1.4.1.4.1.1: Элемент family должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name/given">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name/given не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-33.1.4.1.4.1.2: Элемент given должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name/identity:Patronymic">
			<assert test="count(@nullFlavor)=0">У3-33.1.4.1.4.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/performer/assignedEntity/assignedPerson/name/identity:Patronymic не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-33.1.4.1.4.1.3: Элемент identity:Patronymic должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']">
			<assert test="count(@nullFlavor)=0">У3-33.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-33.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-33.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation">
			<assert test="count(@nullFlavor)=0">У3-33.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-33.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-33.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-33.1.5.1.1: Элемент observation ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор параметра внутри документа)</assert>
			<assert test="count(code)=1">У3-33.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=1">У3-33.1.5.1.3: Элемент observation ДОЛЖЕН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(value)=1">У3-33.1.5.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-33.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.52</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.52$')">У3-33.1.5.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.52</assert>
			<assert test="@extension!=''">У3-33.1.5.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-33.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8020'">У3-33.1.5.1.2: Элемент code обязан содержать один атрибут @code со значением "8020"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-33.1.5.1.2: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-33.1.5.1.2: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.5.1.2: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.5.1.2: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/effectiveTime[not(@nullFlavor)]">
			<assert test="@value!=''">У3-33.1.5.1.3: Элемент effectiveTime должен содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/effectiveTime[@nullFlavor]">
			<assert test="count(@value)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-33.1.5.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8020']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-33.1.5.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@code!=''">У3-33.1.5.1.4: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystem!=''">У3-33.1.5.1.4: Элемент value обязан содержать один атрибут @codeSystem с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.5.1.4: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@codeSystemName!=''">У3-33.1.5.1.4: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.5.1.4: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']">
			<assert test="count(@nullFlavor)=0">У3-33.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-33.1.6: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-33.1.6.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation">
			<assert test="count(@nullFlavor)=0">У3-33.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-33.1.6.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-33.1.6.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-33.1.6.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-33.1.6.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(value)=1">У3-33.1.6.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-33.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='8019'">У3-33.1.6.1.1: Элемент code обязан содержать один атрибут @code со значением "8019"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-33.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-33.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-33.1.6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-33.1.6.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-33.1.6.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SCORES']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1514']/observation/entryRelationship[observation/code/@code='8019']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-33.1.6.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@code!=''">У3-33.1.6.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystem!=''">У3-33.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystem с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-33.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@codeSystemName!=''">У3-33.1.6.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-33.1.6.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']">
			<assert test="count(@nullFlavor)=0">У2-18: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-18.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section">
			<assert test="count(@nullFlavor)=0">У2-18.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-18.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-18.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077'])>=1">У3-34: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/code">
			<assert test="count(@nullFlavor)=0">У2-18.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='DGN'">У2-18.1.1: Элемент code обязан содержать один атрибут @code со значением "DGN"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-18.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-18.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-18.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-18.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/title">
			<assert test="count(@nullFlavor)=0">У2-18.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-18.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']">
			<assert test="count(@nullFlavor)=0">У3-34: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-34.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-34.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=[0,1]">У3-34.1.3: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента effectiveTime</assert>
			<assert test="count(value)=1">У3-34.1.4: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='7026'])=[0,1]">У3-34.1.5: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='12014'])=[0,1]">У3-34.1.6: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='823'])=[0,1]">У3-34.1.7: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='824'])=[0,1]">У3-34.1.8: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='12120'])=[0,1]">У3-34.1.9: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1077','1.2.643.5.1.13.2.1.1.1504.4']">У3-34.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1077"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-34.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-34.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-34.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-34.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-34.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-34.1.4: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1005','1.2.643.5.1.13.2.1.1.641','1.2.643.5.1.13.2.1.1.718']">У3-34.1.4: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1005"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.4: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.4: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.4: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.4: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']">
			<assert test="count(@nullFlavor)=0">У3-34.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-34.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-34.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-34.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7026'">У3-34.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "7026"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-34.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-34.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='7026']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-34.1.5.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.795','1.2.643.5.1.13.13.11.1076']">У3-34.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.795"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.5.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.5.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']">
			<assert test="count(@nullFlavor)=0">У3-34.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-34.1.6: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-34.1.6.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1.6.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1.6.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.6.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-34.1.6.1.2: Элемент observation ДОЛЖЕН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12014'">У3-34.1.6.1.1: Элемент code обязан содержать один атрибут @code со значением "12014"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-34.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']/observation/value[not(@nullFlavor)]">
			<assert test="@xsi:type='CD'">У3-34.1.6.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1049','1.2.643.5.1.13.2.1.1.586']">У3-34.1.6.1.2: Элемент value должен содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1049"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.6.1.2: Элемент value должен содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.6.1.2: Элемент value должен содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.6.1.2: Элемент value должен содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.6.1.2: Элемент value должен содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12014']/observation/value[@nullFlavor]">
			<assert test="@xsi:type='CD'">У3-34.1.6.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="count(@code)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @code</assert>
			<assert test="count(@displayName)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @displayName</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']">
			<assert test="count(@nullFlavor)=0">У3-34.1.7: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-34.1.7: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-34.1.7.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1.7.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1.7.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1.7.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.7.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-34.1.7.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.7.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='823'">У3-34.1.7.1.1: Элемент code обязан содержать один атрибут @code со значением "823"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-34.1.7.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.7.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.7.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.7.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-34.1.7.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='823']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-34.1.7.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1005','1.2.643.5.1.13.2.1.1.641','1.2.643.5.1.13.2.1.1.718']">У3-34.1.7.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1005"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.7.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.7.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.7.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.7.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']">
			<assert test="count(@nullFlavor)=0">У3-34.1.8: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-34.1.8: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-34.1.8.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1.8.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1.8.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1.8.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.8.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-34.1.8.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.8.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='824'">У3-34.1.8.1.1: Элемент code обязан содержать один атрибут @code со значением "824"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-34.1.8.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.8.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.8.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.8.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-34.1.8.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='824']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-34.1.8.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1036','1.2.643.5.1.13.2.1.1.105']">У3-34.1.8.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1036"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.8.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.8.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.8.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.8.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']">
			<assert test="count(@nullFlavor)=0">У3-34.1.9: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-34.1.9: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-34.1.9.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1.9.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1.9.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.9.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(effectiveTime)=[0,1]">У3-34.1.9.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента effectiveTime</assert>
			<assert test="count(value)=1">У3-34.1.9.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
			<assert test="count(entryRelationship[observation/code/@code='12393'])=[0,1]">У3-34.1.9.1.4: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12120'">У3-34.1.9.1.1: Элемент code обязан содержать один атрибут @code со значением "12120"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-34.1.9.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.9.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.9.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.9.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-34.1.9.1.2: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-34.1.9.1.3: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.770'">У3-34.1.9.1.3: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.770"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.9.1.3: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-34.1.9.1.3: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.9.1.3: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.9.1.3: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-34.1.9.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-34.1.9.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']/observation">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-34.1.9.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-34.1.9.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-34.1.9.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-34.1.9.1.4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12393'">У3-34.1.9.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "12393"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-34.1.9.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-34.1.9.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-34.1.9.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-34.1.9.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-34.1.9.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='DGN']/section/entry[observation/code/@codeSystem='1.2.643.5.1.13.13.11.1077']/observation/entryRelationship[observation/code/@code='12120']/observation/entryRelationship[observation/code/@code='12393']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='INT'">У3-34.1.9.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "INT"</assert>
			<assert test="@value!=''">У3-34.1.9.1.4.1.2: Элемент value обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']">
			<assert test="count(@nullFlavor)=0">У2-19: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-19.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section">
			<assert test="count(@nullFlavor)=0">У2-19.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-19.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-19.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='7006'])=1">У3-35: Элемент section ОБЯЗАН содержать один [1..1] элемент entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/code">
			<assert test="count(@nullFlavor)=0">У2-19.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='REGIME'">У2-19.1.1: Элемент code обязан содержать один атрибут @code со значением "REGIME"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-19.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-19.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-19.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-19.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/title">
			<assert test="count(@nullFlavor)=0">У2-19.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-19.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']">
			<assert test="count(@nullFlavor)=0">У3-35: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-35.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']/observation">
			<assert test="count(@nullFlavor)=0">У3-35.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-35.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-35.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-35.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-35.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-35.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='7006'">У3-35.1.1: Элемент code обязан содержать один атрибут @code со значением "7006"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-35.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-35.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-35.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-35.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-35.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='REGIME']/section/entry[observation/code/@code='7006']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-35.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-35.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']">
			<assert test="count(@nullFlavor)=0">У2-20: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-20.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section">
			<assert test="count(@nullFlavor)=0">У2-20.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-20.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-20.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[observation/code/@code='831'])>=1">У3-36: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/code">
			<assert test="count(@nullFlavor)=0">У2-20.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='SERVICES'">У2-20.1.1: Элемент code обязан содержать один атрибут @code со значением "SERVICES"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-20.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-20.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-20.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-20.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/title">
			<assert test="count(@nullFlavor)=0">У2-20.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-20.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']">
			<assert test="count(@nullFlavor)=0">У3-36: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(observation)=1">У3-36.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation">
			<assert test="count(@nullFlavor)=0">У3-36.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-36.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-36.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-36.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-36.1.2: Элемент observation МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-36.1.3: Элемент observation ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(performer)>=0">У3-36.1.4: Элемент observation МОЖЕТ содержать произвольное количество [0..*] элементов performer</assert>
			<assert test="count(entryRelationship[observation/code/@code='12168'])>=1">У3-36.1.5: Элемент observation ОБЯЗАН содержать не менее одного [1..*] элемента entryRelationship</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-36.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='831'">У3-36.1.1: Элемент code обязан содержать один атрибут @code со значением "831"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-36.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-36.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-36.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-36.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/text">
			<assert test="count(@nullFlavor)=0">У3-36.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-36.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-36.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(low)=1">У3-36.1.3.1: Элемент effectiveTime ОБЯЗАН содержать один [1..1] элемент low</assert>
			<assert test="count(high)=[0,1]">У3-36.1.3.2: Элемент effectiveTime МОЖЕТ содержать не более одного [0..1] элемента high</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/effectiveTime/low">
			<assert test="count(@nullFlavor)=0">У3-36.1.3.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/effectiveTime/low не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-36.1.3.1: Элемент low обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/effectiveTime/high">
			<assert test="count(@nullFlavor)=0">У3-36.1.3.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/effectiveTime/high не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-36.1.3.2: Элемент high обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer">
			<assert test="count(@nullFlavor)=0">У3-36.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(modeCode)=[0,1]">У3-36.1.4.1: Элемент performer МОЖЕТ содержать не более одного [0..1] элемента modeCode</assert>
			<assert test="count(assignedEntity)=1">У3-36.1.4.2: Элемент performer ОБЯЗАН содержать один [1..1] элемент assignedEntity</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer/modeCode">
			<assert test="count(@nullFlavor)=0">У3-36.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer/modeCode не должен иметь атрибут @nullFlavor</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.368','1.2.643.5.1.13.2.1.1.734']">У3-36.1.4.1: Элемент modeCode обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.368"</assert>
			<assert test="@codeSystemName!=''">У3-36.1.4.1: Элемент modeCode обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-36.1.4.1: Элемент modeCode обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-36.1.4.1: Элемент modeCode обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-36.1.4.1: Элемент modeCode обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer/assignedEntity">
			<assert test="count(@nullFlavor)=0">У3-36.1.4.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer/assignedEntity не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(id[substring(@root, string-length(@root) - 2)='.70'])=1">У3-36.1.4.2.1: Элемент assignedEntity ОБЯЗАН содержать один [1..1] элемент id (Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer/assignedEntity/id[substring(@root, string-length(@root) - 2)='.70']">
			<assert test="count(@nullFlavor)=0">У3-36.1.4.2.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/performer/assignedEntity/id[substring(@root, string-length(@root) - 2)='.70'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@root!=''">У3-36.1.4.2.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.70$')">У3-36.1.4.2.1: Элемент id обязан содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.70</assert>
			<assert test="@extension!=''">У3-36.1.4.2.1: Элемент id обязан содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']">
			<assert test="count(@nullFlavor)=0">У3-36.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-36.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-36.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']/observation">
			<assert test="count(@nullFlavor)=0">У3-36.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-36.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-36.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-36.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-36.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-36.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='12168'">У3-36.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "12168"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-36.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-36.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-36.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-36.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-36.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='SERVICES']/section/entry[observation/code/@code='831']/observation/entryRelationship[observation/code/@code='12168']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-36.1.5.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.11.1070','1.2.643.5.1.13.2.1.1.473']">У3-36.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.11.1070"</assert>
			<assert test="@codeSystemName!=''">У3-36.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-36.1.5.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-36.1.5.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-36.1.5.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']">
			<assert test="count(@nullFlavor)=0">У2-21: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(section)=1">У2-21.1: Элемент component ОБЯЗАН содержать один [1..1] элемент section</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section">
			<assert test="count(@nullFlavor)=0">У2-21.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(code)=1">У2-21.1.1: Элемент section ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(title)=1">У2-21.1.2: Элемент section ОБЯЗАН содержать один [1..1] элемент title</assert>
			<assert test="count(entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']])>=1">У3-37: Элемент section ОБЯЗАН содержать не менее одного [1..*] элемента entry</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/code">
			<assert test="count(@nullFlavor)=0">У2-21.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='LINKDOCS'">У2-21.1.1: Элемент code обязан содержать один атрибут @code со значением "LINKDOCS"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.197','1.2.643.5.1.13.2.1.1.1504.23','1.2.643.5.1.13.13.11.1379']">У2-21.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.197"</assert>
			<assert test="@codeSystemName!=''">У2-21.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У2-21.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У2-21.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/title">
			<assert test="count(@nullFlavor)=0">У2-21.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/title не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У2-21.1.2: Элемент title должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]">
			<assert test="count(@nullFlavor)=0">У3-37: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']] не должен иметь атрибут @nullFlavor</assert>
			<assert test="count(act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']])=1">У3-37.1: Элемент entry ОБЯЗАН содержать один [1..1] элемент act</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]">
			<assert test="count(@nullFlavor)=0">У3-37.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='ACT'">У3-37.1: Элемент act обязан содержать один атрибут @classCode со значением "ACT"</assert>
			<assert test="@moodCode='EVN'">У3-37.1: Элемент act обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-37.1.1: Элемент act ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(text)=[0,1]">У3-37.1.2: Элемент act МОЖЕТ содержать не более одного [0..1] элемента text</assert>
			<assert test="count(effectiveTime)=1">У3-37.1.3: Элемент act ОБЯЗАН содержать один [1..1] элемент effectiveTime</assert>
			<assert test="count(entryRelationship[observation/code/@code='11002'])=[0,1]">У3-37.1.4: Элемент act МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='11003'])=[0,1]">У3-37.1.5: Элемент act МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(entryRelationship[observation/code/@code='6058'])=[0,1]">У3-37.1.6: Элемент act МОЖЕТ содержать не более одного [0..1] элемента entryRelationship</assert>
			<assert test="count(reference)=1">У3-37.1.7: Элемент act ОБЯЗАН содержать один [1..1] элемент reference</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/code">
			<assert test="count(@nullFlavor)=0">У3-37.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code!=''">У3-37.1.1: Элемент code обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystem!=''">У3-37.1.1: Элемент code обязан содержать один атрибут @codeSystem с не пустым значением; допустимые значения: "1.2.643.5.1.13.13.99.2.1079", "1.2.643.5.1.13.13.11.1522"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.1079', '1.2.643.5.1.13.13.11.1522','1.2.643.5.1.13.2.1.1.646','1.2.643.5.1.13.13.11.1115','1.2.643.5.1.13.13.99.2.195']">У3-37.1.1: Элемент code обязан содержать один атрибут @codeSystem с не пустым значением; допустимые значения: "1.2.643.5.1.13.13.99.2.1079", "1.2.643.5.1.13.13.11.1522"</assert>
			<assert test="@codeSystemVersion!=''">У3-37.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@codeSystemName!=''">У3-37.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-37.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/text">
			<assert test="count(@nullFlavor)=0">У3-37.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/text не должен иметь атрибут @nullFlavor</assert>
			<assert test=".!=''">У3-37.1.2: Элемент text должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/effectiveTime">
			<assert test="count(@nullFlavor)=0">У3-37.1.3: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/effectiveTime не должен иметь атрибут @nullFlavor</assert>
			<assert test="@value!=''">У3-37.1.3: Элемент effectiveTime обязан содержать один атрибут @value с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']">
			<assert test="count(@nullFlavor)=0">У3-37.1.4: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-37.1.4: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-37.1.4.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']/observation">
			<assert test="count(@nullFlavor)=0">У3-37.1.4.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-37.1.4.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-37.1.4.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-37.1.4.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-37.1.4.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-37.1.4.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='11002'">У3-37.1.4.1.1: Элемент code обязан содержать один атрибут @code со значением "11002"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-37.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-37.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-37.1.4.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-37.1.4.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-37.1.4.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11002']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-37.1.4.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-37.1.4.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']">
			<assert test="count(@nullFlavor)=0">У3-37.1.5: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-37.1.5: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-37.1.5.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']/observation">
			<assert test="count(@nullFlavor)=0">У3-37.1.5.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-37.1.5.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-37.1.5.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-37.1.5.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-37.1.5.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-37.1.5.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='11003'">У3-37.1.5.1.1: Элемент code обязан содержать один атрибут @code со значением "11003"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-37.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-37.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-37.1.5.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-37.1.5.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-37.1.5.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='11003']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='ST'">У3-37.1.5.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "ST"</assert>
			<assert test=".!=''">У3-37.1.5.1.2: Элемент value должен содержать не пустое текстовое наполнение</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']">
			<assert test="count(@nullFlavor)=0">У3-37.1.6: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058'] не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='COMP'">У3-37.1.6: Элемент entryRelationship обязан содержать один атрибут @typeCode со значением "COMP"</assert>
			<assert test="count(observation)=1">У3-37.1.6.1: Элемент entryRelationship ОБЯЗАН содержать один [1..1] элемент observation</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']/observation">
			<assert test="count(@nullFlavor)=0">У3-37.1.6.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']/observation не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='OBS'">У3-37.1.6.1: Элемент observation обязан содержать один атрибут @classCode со значением "OBS"</assert>
			<assert test="@moodCode='EVN'">У3-37.1.6.1: Элемент observation обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(code)=1">У3-37.1.6.1.1: Элемент observation ОБЯЗАН содержать один [1..1] элемент code</assert>
			<assert test="count(value)=1">У3-37.1.6.1.2: Элемент observation ОБЯЗАН содержать один [1..1] элемент value</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']/observation/code">
			<assert test="count(@nullFlavor)=0">У3-37.1.6.1.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']/observation/code не должен иметь атрибут @nullFlavor</assert>
			<assert test="@code='6058'">У3-37.1.6.1.1: Элемент code обязан содержать один атрибут @code со значением "6058"</assert>
			<assert test="@codeSystem=['1.2.643.5.1.13.13.99.2.166','1.2.643.5.1.13.2.1.1.1504.41','1.2.643.5.1.13.13.11.1380']">У3-37.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.166"</assert>
			<assert test="@codeSystemName!=''">У3-37.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@displayName!=''">У3-37.1.6.1.1: Элемент code обязан содержать один атрибут @displayName с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-37.1.6.1.1: Элемент code обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']/observation/value">
			<assert test="count(@nullFlavor)=0">У3-37.1.6.1.2: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/entryRelationship[observation/code/@code='6058']/observation/value не должен иметь атрибут @nullFlavor</assert>
			<assert test="@xsi:type='CD'">У3-37.1.6.1.2: Элемент value обязан содержать один атрибут @xsi:type со значением "CD"</assert>
			<assert test="@codeSystem='1.2.643.5.1.13.13.99.2.1008'">У3-37.1.6.1.2: Элемент value обязан содержать один атрибут @codeSystem со значением "1.2.643.5.1.13.13.99.2.1008"</assert>
			<assert test="@codeSystemName!=''">У3-37.1.6.1.2: Элемент value обязан содержать один атрибут @codeSystemName с не пустым значением</assert>
			<assert test="@code!=''">У3-37.1.6.1.2: Элемент value обязан содержать один атрибут @code с не пустым значением</assert>
			<assert test="@codeSystemVersion!=''">У3-37.1.6.1.2: Элемент value обязан содержать один атрибут @codeSystemVersion с не пустым значением</assert>
			<assert test="@displayName!=''">У3-37.1.6.1.2: Элемент value обязан содержать один атрибут @displayName с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference">
			<assert test="count(@nullFlavor)=0">У3-37.1.7: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference не должен иметь атрибут @nullFlavor</assert>
			<assert test="@typeCode='REFR'">У3-37.1.7: Элемент reference обязан содержать один атрибут @typeCode со значением "REFR"</assert>
			<assert test="count(externalDocument)=1">У3-37.1.7.1: Элемент reference ОБЯЗАН содержать один [1..1] элемент externalDocument</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference/externalDocument">
			<assert test="count(@nullFlavor)=0">У3-37.1.7.1: Элемент ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference/externalDocument не должен иметь атрибут @nullFlavor</assert>
			<assert test="@classCode='DOCCLIN'">У3-37.1.7.1: Элемент externalDocument обязан содержать один атрибут @classCode со значением "DOCCLIN"</assert>
			<assert test="@moodCode='EVN'">У3-37.1.7.1: Элемент externalDocument обязан содержать один атрибут @moodCode со значением "EVN"</assert>
			<assert test="count(id[1])=1">У3-37.1.7.1.1: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в МИС)</assert>
			<assert test="count(id[2])=1">У3-37.1.7.1.2: Элемент externalDocument ДОЛЖЕН содержать один [1..1] элемент id (Уникальный идентификатор документа в РЭМД)</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference/externalDocument/id[1][not(@nullFlavor)]">
			<assert test="@root!=''">У3-37.1.7.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+\.51$')">У3-37.1.7.1.1: Элемент id должен содержать один атрибут @root с не пустым значением; допустимый формат значения: OID_медицинской_организации.100.НомерМИС.НомерЭкзМИС.51</assert>
			<assert test="@extension!=''">У3-37.1.7.1.1: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference/externalDocument/id[1][@nullFlavor]">
			<assert test="count(@root)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @root</assert>
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference/externalDocument/id[2][not(@nullFlavor)]">
			<assert test="@root='1.2.643.5.1.13.13.17.1.1'">У3-37.1.7.1.2: Элемент id должен содержать один атрибут @root со значением "1.2.643.5.1.13.13.17.1.1"</assert>
			<assert test="@extension!=''">У3-37.1.7.1.2: Элемент id должен содержать один атрибут @extension с не пустым значением</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument/component/structuredBody/component[section/code/@code='LINKDOCS']/section/entry[act/code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/act[code/@codeSystem=['1.2.643.5.1.13.13.99.2.1079','1.2.643.5.1.13.13.11.1522']]/reference/externalDocument/id[2][@nullFlavor]">
			<assert test="count(@extension)=0">Атрибут nullFlavor не должен быть представлен совместно с атрибутом @extension</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//id[not(@nullFlavor)]">
			<assert test="matches(@root,'^[0-2](\.([1-9][0-9]*|0))+$')">Элемент //id должен иметь синтаксически корректное значение атрибута @root, соответствующее регулярному выражению '([0-2])([.]([1-9][0-9]*|0))+'.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//id[@root='1.2.643.100.3'][not(@nullFlavor)]">
			<assert test="matches(@extension,'^([0-9]{3}[-\s]{0,1}){3}[0-9]{2}$')">Элемент //id[@root='1.2.643.100.3'] должен иметь синтаксически корректное значение атрибута @extension, соответствующее СНИЛС: должно состоять из 11 цифр, цифры могут группироваться по 3+3+3+2, между группами может ставиться пробел или тире.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//postalCode[not(@nullFlavor)]">
			<assert test="matches(.,'^[0-9]{6}$')">Элемент //postalCode должен иметь синтаксически корректное значение, соответствующее почтовому индексу: должно состоять из 6 цифр без разделителей.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//id[not(@nullFlavor)][@root='1.2.643.5.1.13.13.17.1.1']">
			<assert test="matches(@extension,'(^[0-9]{2}[.][0-9]{2}[.][0-9]{3,4}[.][0-9]{9}$|^[0-9]{1,3}[.][0-9]{2}[.][0-9]{2}[.][0-9]{2}[.][0-9]{9}$)')">Элемент //id[@root='1.2.643.5.1.13.13.17.1.1'] должен иметь синтаксически корректное значение атрибута @extension, соответствующее регулярному выражению '^[0-9]{2}[.][0-9]{2}[.][0-9]{3,4}[.][0-9]{9}$' или '^[0-9]{1,3}[.][0-9]{2}[.][0-9]{2}[.][0-9]{2}[.][0-9]{9}$'.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//effectiveTime[not(low|high|width)][not(@nullFlavor)][not(@xsi:type=['IVL_TS','PIVL_TS'])]">
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//birthTime[not(@nullFlavor)]|//time[not(@nullFlavor)]|//effectiveTime/low[not(@nullFlavor)]|//effectiveTime/high[not(@nullFlavor)]|//value[@xsi:type='TS'][not(@nullFlavor)]">
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//identity:effectiveTime/identity:low[not(@nullFlavor)]">
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//identity:effectiveTime/identity:high[not(@nullFlavor)]">
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//identity:IssueDate[not(@nullFlavor)]">
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//identity:IssueDate[not(@nullFlavor)]">
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="ClinicalDocument[id/@root][setId/@root]">
			<assert test="id/@root != setId/@root">Значения атрибута @root элементов ClinicalDocument/id и ClinicalDocument/setId должны различаться.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//identity:Props[not(@nullFlavor)][identity:Ogrn or identity:Ogrnip]">
			<assert test="(identity:Ogrn and not(identity:Ogrnip)) or (identity:Ogrnip and not(identity:Ogrn)) or (identity:Ogrn and identity:Ogrnip/@nullFlavor) or (identity:Ogrn/@nullFlavor and identity:Ogrnip)">ОГРН и ОГРНИП не могут быть указаны совместно.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//*[@xsi:type='PQ'][not(@nullFlavor)]">
			<assert test="@value!=''">Элемент, содержащий @xsi:type='PQ', должен иметь не пустое значение атрибута @value.</assert>
			<assert test="@unit!=''">Элемент, содержащий @xsi:type='PQ', должен иметь не пустое значение атрибута @unit.</assert>
			<assert test="count(translation)&lt;=1">Элемент, содержащий @xsi:type='PQ', должен иметь не более 1 элемента translation.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//*[@xsi:type='ST'][not(@nullFlavor)]">
			<assert test=".!=''">Элемент, содержащий @xsi:type='ST', должен иметь не пустое значение.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//*[@xsi:type='BL'][not(@nullFlavor)]">
			<assert test="@value=['true','false']">Элемент, содержащий @xsi:type='BL', должен иметь значение атрибута @value равное 'true' или 'false'.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//*[@xsi:type='CD'][not(@nullFlavor)]">
			<assert test="@codeSystem!=''">Элемент, содержащий @xsi:type='CD', должен иметь не пустое значение атрибута @codeSystem.</assert>
			<assert test="@codeSystemName!=''">Элемент, содержащий @xsi:type='CD', должен иметь не пустое значение атрибута @codeSystemName.</assert>
			<assert test="@code!=''">Элемент, содержащий @xsi:type='CD', должен иметь не пустое значение атрибута @code.</assert>
			<assert test="@codeSystemVersion!=''">Элемент, содержащий @xsi:type='CD', должен иметь не пустое значение атрибута @codeSystemVersion.</assert>
			<assert test="@displayName!=''">Элемент, содержащий @xsi:type='CD', должен иметь не пустое значение атрибута @displayName.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//*[@xsi:type='INT'][not(@nullFlavor)]">
			<assert test="@value!=''">Элемент, содержащий @xsi:type='INT', должен иметь не пустое значение атрибута @value.</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//*[@xsi:type='TS'][not(@nullFlavor)]">
			<assert test="@value!=''">Элемент, содержащий @xsi:type='TS', должен иметь не пустое значение атрибута @value.</assert>
			<assert test="matches(@value,'^[1-2]{1}[0-9]{3}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(@value,'^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
		</rule>
	</pattern>
    <!-- Проверка наличия корневого элемента -->
    
    <pattern>
        <rule context="/">
            <assert test="count(ClinicalDocument)=1">Main01-1. Документ должен иметь 1 корневой элемент ClinicalDocument.</assert>
        </rule>
    </pattern>
    
    <!-- Для периода времени -->
    
    <pattern>
        <rule context="//*[@xsi:type = 'IVL_TS'][not(@nullFlavor)]">
            <assert test="count(low)&lt;= 1">Элемент, содержащий @xsi:type='IVL_TS', обязан иметь 1 элемент low.</assert>
            <assert test="count(high)&lt;= 1">Элемент, содержащий @xsi:type='IVL_TS', обязан иметь 1 элемент high.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="//*[@xsi:type = 'IVL_TS'][not(@nullFlavor)][high][low]">
            <assert test="low[not(@nullFlavor)]/@value != ''">Элемент, содержащий @xsi:type='IVL_TS', должен иметь не пустое значение атрибута low/@value.</assert>
            <assert test="matches(low[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}$') or matches(low[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(low[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(low[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(low[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
            <assert test="high[not(@nullFlavor)]/@value != ''">Элемент, содержащий @xsi:type='IVL_TS', должен иметь не пустое значение атрибута high/@value.</assert>
            <assert test="matches(high[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}$') or matches(high[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}$') or matches(high[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}$') or matches(high[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$') or matches(high[not(@nullFlavor)]/@value, '^[1-2]{1}[0-9]{3}[0-1]{1}[0-9]{1}[0-3]{1}[0-9]{1}[0-2]{1}[0-9]{1}[0-5]{1}[0-9]{1}[0-5]{1}[0-9]{1}\+[0-2]{1}[0-9]{1}[0-5]{1}[0]{1}$')">Дата должна соответствовать формату "YYYYMMDDHHmmSS +| ZZZZ", где "YYYY" – год, "ММ" – месяц, "HH" - часы, "mm" - минуты, "SS" - секунды, " +| ZZZZ" - указатель временной зоны.</assert>
        </rule>
    </pattern>
    
    <!-- Дополнительные правила для блока "Сведения об источнике оплаты" -->
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo][code/@code = ['8', '9', '10', '11', '12']]">
            <assert test="identity:DocInfo/@nullFlavor = ['NA', 'NAV']">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo должен иметь значение атрибута @nullFlavor равное 'NA' или 'NAV'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:IdentityDocType][code/@code = '1']">
            <assert test="identity:DocInfo/identity:IdentityDocType/@code = '1'">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:IdentityDocType должен иметь значение атрибута @code равное '1'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:IdentityDocType][code/@code = '3']">
            <assert test="identity:DocInfo/identity:IdentityDocType/@code = '2'">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:IdentityDocType должен иметь значение атрибута @code равное '2'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:IdentityDocType][code/@code = ['4', '5', '6']]">
            <assert test="identity:DocInfo/identity:IdentityDocType/@code = '3'">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:IdentityDocType должен иметь значение атрибута @code равное '3'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:InsurancePolicyType/@nullFlavor][identity:DocInfo/identity:IdentityDocType/@code = '1']">
            <assert test="identity:DocInfo/identity:InsurancePolicyType/@nullFlavor = 'NAV'">Main07-1. Элемент
                ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:InsurancePolicyType должен иметь значение атрибута @nullFlavor равное 'NAV'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:InsurancePolicyType][identity:DocInfo/identity:IdentityDocType/@code = ['2', '3']]">
            <assert test="identity:DocInfo/identity:InsurancePolicyType/@nullFlavor = 'NA'">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:InsurancePolicyType должен иметь значение атрибута @nullFlavor равное 'NA'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:Number][identity:DocInfo/identity:InsurancePolicyType/@nullFlavor = 'NAV']">
            <assert test="identity:DocInfo/identity:Number/@nullFlavor = 'NAV'">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:Number должен иметь значение атрибута @nullFlavor равное 'NAV'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:Number][identity:DocInfo/identity:InsurancePolicyType[not(@nullFlavor = 'NAV')]]">
            <assert test="identity:DocInfo/identity:Number != ''">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:Number должен иметь не пустое значение.</assert>
            <assert test="count(identity:DocInfo/identity:Number/@nullFlavor)=0">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:Number не должен иметь атрибут @nullFlavor.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo/identity:effectiveTime][identity:DocInfo/identity:InsurancePolicyType/@nullFlavor = 'NAV']">
            <assert test="identity:DocInfo/identity:effectiveTime/@nullFlavor = ['NAV', 'NASK']">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo/identity:effectiveTime должен иметь значение атрибута @nullFlavor равное 'NAV' или 'NASK'.</assert>
        </rule>
    </pattern>
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity/scopingOrganization/id[@nullFlavor]">
            <assert test="@nullFlavor = 'NA'">Main07-1. Элемент ClinicalDocument/participant/associatedEntity/scopingOrganization/id должен иметь значение атрибута @nullFlavor равное 'NA'.</assert>
        </rule>
    </pattern>
    
    <!-- Соответствие наполнения таблице для блока "Сведения об источнике оплаты" --> 
    
    <pattern>
        <rule context="ClinicalDocument/participant[@typeCode = 'IND']/associatedEntity[identity:DocInfo][code/@code = ['1', '3', '4', '5', '6']]">
            <assert test="count(identity:DocInfo/@nullFlavor)=0"> Элемент ClinicalDocument/participant/associatedEntity/identity:DocInfo не должен иметь атрибут @nullFlavor при указании данного типа источника оплаты в соответствии с Таблицей "Обязательность заполнения элементов в зависимости от источника оплаты", представленной в руководстве по реализации в разделе "Сведения об источнике оплаты".</assert>
        </rule>
    </pattern>
	
	<pattern>
		<rule context="ClinicalDocument/documentationOf/serviceEvent[performer/@typeCode = 'SPRF']">
			<assert test="exists(performer[@typeCode = 'PPRF'])">Элемент performer со значением атрибута typeCode= "SPRF" (ассистент) не должен использоваться при отсутствии элемента performer со значением атрибута typeCode="PPRF" (непосредственный исполнитель).</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//administrativeGenderCode[@codeSystem='1.2.643.5.1.13.13.11.1040']">
			<assert test="@code=['1','2']">Допустимые значения для элементов administrativeGenderCode[@codeSystem='1.2.643.5.1.13.13.11.1040']: 1, 2</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//address:Type[@codeSystem='1.2.643.5.1.13.13.11.1504']">
			<assert test="@code=['1','2','3']">Допустимые значения для элементов address:Type[@codeSystem='1.2.643.5.1.13.13.11.1504']: 1, 2, 3</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//code[@codeSystem='1.2.643.5.1.13.13.11.1520']">
			<assert test="@code=['227']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.11.1520']: 227</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['800','801','804','806','808','811','812','814','815','823','824','831','835','836','4058','4083','6026','6034','6058','7003','7006','7026','7028','8019','8020','8034','8040','8041','8043','8102','9052','9053','11002','11003','11036','12006','12014','12120','12168','12310','12328','12393','12475','12524']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 800, 801, 804, 806, 808, 811, 812, 814, 815, 823, 824, 831, 835, 836, 4058, 4083, 6026, 6034, 6058, 7003, 7006, 7026, 7028, 8019, 8020, 8034, 8040, 8041, 8043, 8102, 9052, 9053, 11002, 11003, 11036, 12006, 12014, 12120, 12168, 12310, 12328, 12393, 12475, 12524</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//code[@codeSystem='1.2.643.5.1.13.13.99.2.197']">
			<assert test="@code=['ALL','ANAM','BENEFITS','COMMISSION','COMPLNTS','CONSILIUMDECISION','DGN','DOCINFO','DRUG','ELSEPROCEDURE','EPIDEM','GISTRESULT','LANAM','LINKDOCS','OBSTETRICANAMN','REGIME','RESCONS','RESINSTR','RESLAB','SCORES','SERVICES','SOCANAM','SUR','TRANSFUSINFO','VITALPARAM']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.197']: ALL, ANAM, BENEFITS, COMMISSION, COMPLNTS, CONSILIUMDECISION, DGN, DOCINFO, DRUG, ELSEPROCEDURE, EPIDEM, GISTRESULT, LANAM, LINKDOCS, OBSTETRICANAMN, REGIME, RESCONS, RESINSTR, RESLAB, SCORES, SERVICES, SOCANAM, SUR, TRANSFUSINFO, VITALPARAM</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='DOCINFO']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['800','801','7003','804','836','806','808']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 800, 801, 7003, 804, 836, 806, 808</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='BENEFITS']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['811']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 811</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='COMPLNTS']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['835']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 835</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='ANAM']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7006']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7006</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7006']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7006</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section/code[@codeSystem='1.2.643.5.1.13.13.99.2.197']">
			<assert test="@code=['SOCANAM','OBSTETRICANAMN','ALL','EPIDEM']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.197']: SOCANAM, OBSTETRICANAMN, ALL, EPIDEM</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='SOCANAM']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['814','812','9052','9053','12524','12006']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 814, 812, 9052, 9053, 12524, 12006</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='SOCANAM']/entry/observation[code/@code='814']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['8043','815','8040','4058']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 8043, 815, 8040, 4058</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='SOCANAM']/entry/observation[code/@code='814']/entryRelationship/observation[code/@code='8040']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['8041']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 8041</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='SOCANAM']/entry/observation[code/@code='814']/entryRelationship/observation[code/@code='4058']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['4083']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 4083</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='OBSTETRICANAMN']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7006','12310']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7006, 12310</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='ALL']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['11036']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 11036</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='ALL']/entry/observation[code/@code='11036']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['12328']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 12328</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LANAM']/component/section[code/@code='EPIDEM']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7006']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7006</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='CONSILIUMDECISION']/entry/observation/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['6026']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 6026</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='COMMISSION']/entry/observation/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['12475']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 12475</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='RESLAB']/entry/observation/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7028']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7028</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='RESLAB']/entry/observation/entryRelationship/observation[code/@code='7028']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['8102']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 8102</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='VITALPARAM']/entry/organizer/component/observation/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['6034','8034']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 6034, 8034</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='SCORES']/entry/observation/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['8020','8019']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 8020, 8019</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='DGN']/entry/observation/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7026','12014','823','824','12120']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7026, 12014, 823, 824, 12120</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='DGN']/entry/observation/entryRelationship/observation[code/@code='12120']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['12393']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 12393</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='REGIME']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['7006']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 7006</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='SERVICES']/entry/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['831']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 831</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='SERVICES']/entry/observation[code/@code='831']/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['12168']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 12168</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//section[code/@code='LINKDOCS']/entry/act/entryRelationship/observation/code[@codeSystem='1.2.643.5.1.13.13.99.2.166']">
			<assert test="@code=['11002','11003','6058']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.166']: 11002, 11003, 6058</assert>
		</rule>
	</pattern>
	<pattern>
		<rule context="//code[@codeSystem='1.2.643.5.1.13.13.99.2.726']">
			<assert test="@code=['1']">Допустимые значения для элементов code[@codeSystem='1.2.643.5.1.13.13.99.2.726']: 1</assert>
		</rule>
	</pattern>
</schema>
